# AIGER-Net Anonymous Reproducibility Package

This repository implements the data audit, artist-grouped evaluation, AIGER-Net modules, calibration, robustness analysis, and statistical reporting described in the manuscript **Artist Identity Guided Evidence Calibrated Multimodal Graph Learning for Cross Dataset Painting Style Prediction**.

## Artifact status

The source code and configuration files define the intended reproduction workflow. Files under `records/reference_only/` are target-format records for pipeline checking and result-schema validation. They were not produced by model training and must not be cited as empirical evidence. Replace them with records written under `records/empirical/` by completed runs before any result is reported as reproduced.

## Repository map

| Path | Purpose |
| --- | --- |
| `configs/` | Base, fold, ablation, baseline, robustness, and seed settings |
| `metadata/` | Field dictionary, label map, and machine-readable schemas |
| `src/aiger_net/` | Data, model, training, calibration, evaluation, and statistics code |
| `scripts/` | Ordered command-line entry points for the full workflow |
| `tests/` | Deterministic checks for metrics, calibration, splitting, and package contracts |
| `records/reference_only/` | Non-empirical target records and expected report layout |

## Data acquisition

The package does not redistribute artwork images. Download the two public Kaggle releases with the Kaggle command-line client:

```bash
kaggle datasets download -d steubk/wikiart -p data/raw/wikiart --unzip
kaggle datasets download -d ikarus777/best-artworks-of-all-time -p data/raw/best_artworks --unzip
```

Access and reuse remain subject to the terms attached to the archived Kaggle releases and underlying artwork sources.

## Environment

Python 3.11 and CUDA 12.1 are the locked reference environment. Create it with either command below.

```bash
conda env create -f environment.yml
conda activate aiger-net
```

or

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e .
```

The foundation encoder is frozen by default. Online encoding requires authenticated access to the model named in `configs/base.yaml`; alternatively, fold-safe precomputed embeddings can be supplied through the manifest columns defined in `metadata/field_dictionary.csv`.

## Core reproduction sequence

```bash
bash scripts/run_full_pipeline.sh configs/base.yaml
```

The command runs the ordered core stages:

1. validate the software and hardware environment;
2. build the WikiArt and Best Artworks manifests;
3. audit integrity, artist overlap, labels, and duplicate components;
4. construct five artist-grouped outer folds and inner calibration partitions;
5. train AIGER-Net and the five native embedding baselines;
6. evaluate internal out-of-fold and external weak-label endpoints;
7. export the available empirical records.

Training and evaluation stages write metadata records containing the configuration digest, source revision, seed, input-manifest digest, and output digest. A stage refuses to overwrite an existing empirical record unless `--force` is supplied.

Extended analyses are launched separately so that a failed sensitivity run cannot overwrite the principal artifacts:

```bash
python scripts/09_run_ablations.py --config configs/base.yaml --all
python scripts/10_run_robustness.py --config configs/base.yaml --condition CONDITION_ID --probabilities PATH_TO_ARRAY --metadata PATH_TO_PARQUET
python scripts/11_run_statistics.py --input records/empirical/all_fold_metrics.csv
```

The corruption functions and severity grids are defined in `src/aiger_net/robustness.py` and `configs/robustness.yaml`. Reduced-artist conditions must refit the complete pipeline; fixed-model corruption conditions must first create a prediction bundle and then pass that bundle to the scorer. Seed and perceptual-hash sensitivity runs use the same commands with the overrides in `configs/seeds.yaml` and `configs/robustness.yaml`.

## Dataset boundary

- Development data: WikiArt work-level style labels.
- External data: Best Artworks artist-associated movement sets.
- All 50 normalized external artist identities are excluded from model development before fold construction.
- Outer validation artists, exact duplicates, and confirmed near-duplicate components never enter the corresponding training partition.
- Padding statistics, projections, prototypes, retrieval memory, temperature, APS quantile, and rejection thresholds are fitted inside the relevant outer-training boundary.
- External images and movement sets are not used for model fitting, selection, calibration, or thresholding.
- Strict external inference sets the text mask to zero.

## Principal configuration

- five artist-grouped outer folds;
- three artist-grouped inner folds;
- 10% artist-disjoint calibration subset inside each outer-training partition;
- primary random seed 29, with sensitivity seeds 13 and 47;
- 448-pixel long side with square padding;
- 512-dimensional task space;
- Top-2 sparse router;
- two relation-aware graph layers;
- AdamW, effective batch size 128, five-epoch warm-up, cosine decay;
- maximum 80 epochs and patience 10;
- 2,000 artist-clustered bootstrap replicates.

## Empirical record policy

Only files written by an actual run under `records/empirical/` qualify as reproduction evidence. Every such record includes `record_status: empirical`, the command, environment fingerprint, source revision, configuration hash, manifest hash, timestamps, and checkpoint digest. The reporting script rejects `reference-only` records unless `--allow-reference-only` is explicitly set for schema checking.

## Third-party baselines

Baseline definitions and their 30-trial search domains are fixed in `configs/baselines.yaml`. The five embedding routes supported by `scripts/08_run_baselines.py` write empirical fold records. TabNet, FT-Transformer, ResNet-50, ViT-B/16, Swin-T, and DINOv2 must be run with their declared feature-token or image-backbone routes while preserving the same fold manifest and calibration protocol. MCS-Net and ArtNAS-Style additionally require verified public implementations. Register exact repository URLs, revisions, and licenses in `third_party/LOCK.json` before running those two models. The adapter rejects an empty or mutable revision so that unverified code cannot silently enter a reported comparison.

## Verification

```bash
python scripts/validate_package.py
python scripts/13_validate_reference_matrix.py
PYTHONPATH=src python -m unittest discover -s tests -v
```

The validator checks configuration completeness, result schemas, anonymous metadata, prohibited reference-record use, and source syntax. It does not certify that GPU training has been completed.

## Anonymity

The repository contains no author names, affiliations, personal paths, credentials, or identifying repository account. Add the anonymous repository URL only in the submission system or in the manuscript Code Availability statement.

