import unittest

import numpy as np

from aiger_net.statistics import holm_adjust, matched_fold_contrast


class StatisticTests(unittest.TestCase):
    def test_holm_adjustment_is_not_smaller_than_raw_values(self):
        raw = [0.001, 0.020, 0.040]
        adjusted = holm_adjust(raw)
        self.assertTrue(all(left <= right for left, right in zip(raw, adjusted, strict=True)))
        self.assertTrue(all(0.0 <= value <= 1.0 for value in adjusted))

    def test_matched_contrast_uses_paired_differences(self):
        left = np.asarray([0.71, 0.72, 0.70, 0.73, 0.72])
        right = np.asarray([0.69, 0.70, 0.68, 0.71, 0.70])
        mean, interval, p_value = matched_fold_contrast(left, right)
        self.assertTrue(np.isclose(mean, 0.02))
        self.assertLessEqual(interval[0], mean)
        self.assertLessEqual(mean, interval[1])
        self.assertLessEqual(0.0, p_value)
        self.assertLessEqual(p_value, 1.0)
