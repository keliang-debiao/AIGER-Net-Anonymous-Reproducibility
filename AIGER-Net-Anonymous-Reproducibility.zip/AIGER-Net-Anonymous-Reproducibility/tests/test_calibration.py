import unittest

import numpy as np

from aiger_net.calibration import APSCalibrator, TemperatureScaler


class CalibrationTests(unittest.TestCase):
    def test_temperature_scaler_preserves_probability_rows(self):
        probabilities = np.asarray([[0.8, 0.2], [0.55, 0.45], [0.1, 0.9]])
        labels = np.asarray([0, 1, 1])
        calibrated = TemperatureScaler().fit(probabilities, labels).transform(probabilities)
        self.assertEqual(calibrated.shape, probabilities.shape)
        self.assertTrue(np.allclose(calibrated.sum(axis=1), 1.0))

    def test_aps_contains_at_least_one_class(self):
        probabilities = np.asarray([[0.8, 0.1, 0.1], [0.2, 0.7, 0.1], [0.2, 0.2, 0.6]])
        labels = np.asarray([0, 1, 2])
        sets = APSCalibrator(0.90).fit(probabilities, labels).sets(probabilities)
        self.assertEqual(sets.dtype, bool)
        self.assertTrue(np.all(sets.sum(axis=1) >= 1))
