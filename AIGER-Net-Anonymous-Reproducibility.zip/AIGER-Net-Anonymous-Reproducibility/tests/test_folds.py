import unittest

import pandas as pd

from aiger_net.data.folds import assert_no_boundary_leakage, leakage_safe_groups


class FoldTests(unittest.TestCase):
    def test_artist_and_duplicate_links_form_single_groups(self):
        frame = pd.DataFrame(
            {
                "artist_id": ["a", "b", "c", "d"],
                "duplicate_component": ["x", "x", "y", "z"],
                "style_id": [0, 0, 1, 1],
            }
        )
        groups = leakage_safe_groups(frame)
        self.assertEqual(groups.iloc[0], groups.iloc[1])
        self.assertNotEqual(groups.iloc[2], groups.iloc[3])

    def test_boundary_check_accepts_disjoint_assignments(self):
        frame = pd.DataFrame(
            {
                "artist_id": ["a", "a", "b", "b"],
                "duplicate_component": ["x", "x", "y", "y"],
                "outer_fold": [0, 0, 1, 1],
            }
        )
        assert_no_boundary_leakage(frame)
