import subprocess
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class ReferenceMatrixTests(unittest.TestCase):
    def test_cross_file_consistency(self):
        result = subprocess.run(
            [sys.executable, str(ROOT / "scripts/13_validate_reference_matrix.py")],
            cwd=ROOT,
            check=False,
            capture_output=True,
            text=True,
        )
        self.assertEqual(result.returncode, 0, msg=result.stdout + result.stderr)
