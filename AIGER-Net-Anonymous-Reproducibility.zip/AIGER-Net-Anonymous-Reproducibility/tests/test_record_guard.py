import json
import tempfile
import unittest
from pathlib import Path

from aiger_net.reporting import load_records


class RecordGuardTests(unittest.TestCase):
    def test_reference_record_is_rejected_by_default(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "record.json"
            path.write_text(json.dumps({"record_status": "reference-only"}), encoding="utf-8")
            with self.assertRaises(RuntimeError):
                load_records([path])
            loaded = load_records([path], allow_reference_only=True)
            self.assertEqual(loaded[0]["record_status"], "reference-only")
