import unittest

import numpy as np

from aiger_net.metrics import classification_metrics, multiclass_brier, partial_label_metrics


class MetricTests(unittest.TestCase):
    def test_classification_metrics_are_bounded(self):
        probabilities = np.asarray([[0.8, 0.2], [0.4, 0.6], [0.7, 0.3]])
        labels = np.asarray([0, 1, 1])
        metrics = classification_metrics(probabilities, labels, bins=2)
        for key in ("macro_f1", "balanced_accuracy", "top1_accuracy", "ece", "aurc"):
            self.assertLessEqual(0.0, metrics[key])
            self.assertLessEqual(metrics[key], 1.0)
        self.assertTrue(np.isclose(metrics["brier"], multiclass_brier(probabilities, labels)))

    def test_partial_label_hit_accepts_any_admissible_class(self):
        probabilities = np.asarray([[0.1, 0.6, 0.3], [0.7, 0.2, 0.1]])
        allowed = [{1, 2}, {2}]
        metrics = partial_label_metrics(probabilities, allowed)
        self.assertEqual(metrics["set_hit_at_1"], 0.5)
        self.assertEqual(metrics["top3_coverage"], 1.0)
