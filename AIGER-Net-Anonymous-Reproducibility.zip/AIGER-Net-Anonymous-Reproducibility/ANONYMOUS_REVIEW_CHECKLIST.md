# Anonymous review checklist

- No author name, affiliation, email address, personal account, local home path, access token, or private repository URL is included.
- Raw artwork images, copyrighted dataset archives, checkpoints, and credentials are excluded.
- Public dataset identifiers, eligibility rules, label harmonization, fold assignment, and duplicate controls are machine readable.
- Primary and sensitivity configurations are versioned.
- AIGER-Net, loss terms, fold memory, calibration, prediction sets, rejection, metrics, bootstrap intervals, and paired statistics are implemented.
- Reference-only records carry explicit non-empirical status and are rejected by the empirical reporting path.
- Empirical records include configuration, manifest, source, checkpoint, prediction, seed, fold, and environment provenance.
- Third-party code is blocked until its URL, immutable revision, and license are verified.
- Package validation, reference-matrix validation, and ten deterministic tests pass before archive creation.
