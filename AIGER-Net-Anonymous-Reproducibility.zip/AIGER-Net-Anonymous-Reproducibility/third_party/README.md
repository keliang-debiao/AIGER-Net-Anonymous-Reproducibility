# Third-party source control

The two art-specific comparators are permitted to run only after `LOCK.json` contains a public source URL, an immutable revision, a license, and `status: verified`.

The MCS-Net source URL and Apache-2.0 license are recorded, but an immutable revision must be inserted after the archive used for the run is obtained. No public ArtNAS-Style implementation was assumed by this package; its source fields remain empty until an author-released archive or repository can be verified. The baseline adapter stops rather than substituting a different architecture.

For anonymous review, do not add private repository URLs, account names, access tokens, or local user paths. A source archive may be stored outside this package and identified only by its public URL, revision, and SHA-256 digest.
