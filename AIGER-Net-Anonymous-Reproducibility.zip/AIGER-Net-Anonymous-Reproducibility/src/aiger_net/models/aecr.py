from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import torch
from torch import nn

from .layers import l2_normalize


@dataclass(frozen=True)
class RetrievalResult:
    indices: np.ndarray
    scores: np.ndarray


class ArtistExcludedIndex:
    def __init__(
        self,
        embeddings: np.ndarray,
        artist_ids: np.ndarray,
        duplicate_components: np.ndarray,
        labels: np.ndarray,
    ):
        values = np.asarray(embeddings, dtype=np.float32)
        norms = np.linalg.norm(values, axis=1, keepdims=True)
        self.embeddings = values / np.clip(norms, 1.0e-8, None)
        self.artist_ids = np.asarray(artist_ids)
        self.duplicate_components = np.asarray(duplicate_components)
        self.labels = np.asarray(labels)

    def query(
        self,
        embedding: np.ndarray,
        query_artist: str | None,
        query_duplicate_component: str | None,
        k: int,
    ) -> RetrievalResult:
        vector = np.asarray(embedding, dtype=np.float32)
        vector = vector / max(float(np.linalg.norm(vector)), 1.0e-8)
        scores = self.embeddings @ vector
        eligible = np.ones(len(scores), dtype=bool)
        if query_artist is not None:
            eligible &= self.artist_ids != query_artist
        if query_duplicate_component is not None:
            eligible &= self.duplicate_components != query_duplicate_component
        candidates = np.flatnonzero(eligible)
        if len(candidates) < k:
            raise ValueError(f"only {len(candidates)} eligible retrieval candidates for k={k}")
        order = candidates[np.argpartition(scores[candidates], -k)[-k:]]
        order = order[np.argsort(scores[order])[::-1]]
        return RetrievalResult(indices=order, scores=scores[order])


class EvidenceCalibrationHead(nn.Module):
    def __init__(self, width: int, num_classes: int):
        super().__init__()
        self.bilinear = nn.Bilinear(width, width, 1, bias=False)
        self.evidence = nn.Linear(width * 2, num_classes)

    def aggregate(
        self,
        query: torch.Tensor,
        neighbor_embeddings: torch.Tensor,
        neighbor_prototypes: torch.Tensor,
        beta: float = 1.0,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        batch, neighbors, width = neighbor_embeddings.shape
        if neighbors == 0:
            return torch.zeros_like(query), query.new_zeros((batch, 0))
        expanded = query[:, None, :].expand(batch, neighbors, width)
        compatibility = self.bilinear(
            expanded.reshape(-1, width), neighbor_embeddings.reshape(-1, width)
        ).reshape(batch, neighbors)
        prototype_agreement = torch.nn.functional.cosine_similarity(
            expanded, neighbor_prototypes, dim=-1
        )
        weights = torch.softmax(compatibility + beta * prototype_agreement, dim=-1)
        summary = torch.sum(weights.unsqueeze(-1) * neighbor_embeddings, dim=1)
        return summary, weights

    def forward(self, query: torch.Tensor, evidence_summary: torch.Tensor):
        evidence = torch.nn.functional.softplus(
            self.evidence(torch.cat([query, evidence_summary], dim=-1))
        )
        alpha = evidence + 1.0
        strength = alpha.sum(dim=-1, keepdim=True)
        probabilities = alpha / strength
        uncertainty = alpha.shape[-1] / strength.squeeze(-1)
        return evidence, alpha, probabilities, uncertainty


def retrieval_diagnostics(
    query_labels: np.ndarray,
    retrieved_labels: np.ndarray,
    retrieved_artists: np.ndarray,
) -> dict[str, float]:
    precision = np.mean(retrieved_labels == query_labels[:, None])
    diversity = np.mean([len(set(row.tolist())) / row.size for row in retrieved_artists])
    return {"retrieval_precision_at_5": float(precision), "artist_diversity_at_5": float(diversity)}

