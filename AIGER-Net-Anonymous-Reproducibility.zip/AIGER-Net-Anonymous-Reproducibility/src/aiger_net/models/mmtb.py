from __future__ import annotations

import torch
from torch import nn

from .layers import MLP, l2_normalize


class PrototypeGate(nn.Module):
    def __init__(self, width: int):
        super().__init__()
        self.gate = nn.Linear(width * 2, width)

    def forward(self, visual: torch.Tensor, textual: torch.Tensor) -> torch.Tensor:
        reliability = torch.sigmoid(self.gate(torch.cat([visual, textual], dim=-1)))
        return l2_normalize(reliability * visual + (1.0 - reliability) * textual)


class SparseExpertRouter(nn.Module):
    def __init__(
        self,
        diagnostic_width: int,
        expert_count: int = 3,
        top_k: int = 2,
        uniform: bool = False,
    ):
        super().__init__()
        self.top_k = top_k
        self.uniform = uniform
        self.network = nn.Sequential(
            nn.Linear(diagnostic_width, 32),
            nn.GELU(),
            nn.Linear(32, expert_count),
        )

    def forward(self, diagnostics: torch.Tensor, text_mask: torch.Tensor) -> torch.Tensor:
        logits = self.network(diagnostics)
        unavailable_text = text_mask.reshape(-1).eq(0)
        logits[unavailable_text, 1] = float("-inf")
        if self.uniform:
            available = torch.isfinite(logits).to(logits.dtype)
            return available / available.sum(dim=-1, keepdim=True).clamp_min(1.0)
        k = min(self.top_k, logits.shape[-1])
        values, indices = torch.topk(logits, k=k, dim=-1)
        masked = torch.full_like(logits, float("-inf"))
        masked.scatter_(1, indices, values)
        return torch.softmax(masked, dim=-1)

    @staticmethod
    def load_balance_loss(weights: torch.Tensor) -> torch.Tensor:
        mean_usage = weights.mean(dim=0)
        target = torch.full_like(mean_usage, 1.0 / weights.shape[-1])
        return (mean_usage - target).pow(2).mean()


class RelationAwareLayer(nn.Module):
    def __init__(self, width: int, relation_count: int, dropout: float):
        super().__init__()
        self.relation = nn.Embedding(relation_count, width)
        self.key = nn.Linear(width, width, bias=False)
        self.query = nn.Linear(width, width, bias=False)
        self.value = nn.ModuleList(nn.Linear(width, width, bias=False) for _ in range(relation_count))
        self.reliability = nn.Linear(1, width, bias=False)
        self.norm = nn.LayerNorm(width)
        self.dropout = nn.Dropout(dropout)
        self.scale = width**-0.5

    def forward(
        self,
        nodes: torch.Tensor,
        relation_ids: torch.Tensor,
        node_mask: torch.Tensor,
        router_reliability: torch.Tensor,
    ) -> torch.Tensor:
        batch, node_count, _ = nodes.shape
        query = self.query(nodes[:, :1, :])
        keys = self.key(nodes)
        relation_bias = self.relation(relation_ids).unsqueeze(0)
        reliability_bias = self.reliability(router_reliability[:, None, None])
        scores = ((query * (keys + relation_bias + reliability_bias)).sum(dim=-1) * self.scale)
        scores = scores.masked_fill(~node_mask, float("-inf"))
        attention = torch.softmax(scores, dim=-1)
        transformed = torch.zeros_like(nodes)
        for relation in range(len(self.value)):
            relation_mask = relation_ids.eq(relation).view(1, node_count, 1)
            transformed = transformed + self.value[relation](nodes) * relation_mask
        message = torch.sum(attention.unsqueeze(-1) * transformed, dim=1)
        updated_query = self.norm(nodes[:, 0, :] + self.dropout(message))
        output = nodes.clone()
        output[:, 0, :] = updated_query
        return output


class MissingModalityTopologyBinding(nn.Module):
    def __init__(
        self,
        width: int,
        hidden_width: int,
        relation_count: int,
        graph_layers: int,
        router_top_k: int,
        dropout: float,
        uniform_router: bool = False,
        graph_replacement: str = "none",
    ):
        super().__init__()
        self.image_expert = MLP(width, width, hidden_width, dropout)
        self.multimodal_expert = MLP(width * 2 + 1, width, hidden_width, dropout)
        self.prototype_expert = MLP(width * 2, width, hidden_width, dropout)
        self.router = SparseExpertRouter(
            4,
            expert_count=3,
            top_k=router_top_k,
            uniform=uniform_router,
        )
        self.layers = nn.ModuleList(
            RelationAwareLayer(width, relation_count, dropout) for _ in range(graph_layers)
        )
        self.graph_replacement = graph_replacement
        self.concatenation_mlp = MLP(width * 2, width, hidden_width, dropout)

    def forward(
        self,
        image: torch.Tensor,
        text: torch.Tensor,
        text_mask: torch.Tensor,
        nearest_prototype: torch.Tensor,
        local_nodes: torch.Tensor,
        relation_ids: torch.Tensor,
        node_mask: torch.Tensor,
        preliminary_entropy: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        mask = text_mask.reshape(-1, 1)
        disagreement = 1.0 - torch.nn.functional.cosine_similarity(image, text, dim=-1)
        prototype_distance = 1.0 - torch.nn.functional.cosine_similarity(
            image, nearest_prototype, dim=-1
        )
        diagnostics = torch.stack(
            [mask.reshape(-1), disagreement, prototype_distance, preliminary_entropy], dim=-1
        )
        weights = self.router(diagnostics, mask)
        experts = torch.stack(
            [
                self.image_expert(image),
                self.multimodal_expert(torch.cat([image, text, mask], dim=-1)),
                self.prototype_expert(torch.cat([image, nearest_prototype], dim=-1)),
            ],
            dim=1,
        )
        query = torch.sum(weights.unsqueeze(-1) * experts, dim=1)
        nodes = local_nodes.clone()
        nodes[:, 0, :] = query
        reliability = weights.max(dim=-1).values
        if not self.layers and self.graph_replacement == "concatenation_mlp":
            context_mask = node_mask[:, 1:].unsqueeze(-1).to(nodes.dtype)
            context = (nodes[:, 1:, :] * context_mask).sum(dim=1)
            context = context / context_mask.sum(dim=1).clamp_min(1.0)
            query = self.concatenation_mlp(torch.cat([query, context], dim=-1))
            nodes[:, 0, :] = query
        for layer in self.layers:
            nodes = layer(nodes, relation_ids, node_mask, reliability)
        return nodes[:, 0, :], weights, self.router.load_balance_loss(weights)

