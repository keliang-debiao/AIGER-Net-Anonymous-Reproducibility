from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import nn

from .aecr import EvidenceCalibrationHead
from .casd import CrossArtistStyleDisentanglement
from .layers import MLP, l2_normalize
from .mmtb import MissingModalityTopologyBinding, PrototypeGate


@dataclass
class AIGEROutput:
    probabilities: torch.Tensor
    alpha: torch.Tensor
    evidence: torch.Tensor
    uncertainty: torch.Tensor
    query: torch.Tensor
    style_code: torch.Tensor
    artist_logits: torch.Tensor
    router_weights: torch.Tensor
    retrieval_weights: torch.Tensor
    routing_loss: torch.Tensor
    logits: torch.Tensor | None


class AIGERNet(nn.Module):
    def __init__(self, config: dict, num_artists: int):
        super().__init__()
        model = config["model"]
        foundation = config["foundation"]
        width = int(model["task_width"])
        hidden = int(model["hidden_width"])
        dropout = float(model["dropout"])
        classes = int(model["num_classes"])
        embedding_width = int(foundation["embedding_width"])
        self.num_classes = classes
        self.output_head = str(model.get("output_head", "evidential"))
        self.image_projection = nn.Sequential(
            nn.Linear(embedding_width, width), nn.LayerNorm(width)
        )
        self.text_projection = nn.Sequential(
            nn.Linear(embedding_width, width), nn.LayerNorm(width)
        )
        self.missing_text = nn.Parameter(torch.zeros(width))
        self.preliminary_head = nn.Linear(width, classes)
        self.prototype_gate = PrototypeGate(width)
        self.casd = CrossArtistStyleDisentanglement(
            width,
            hidden,
            num_artists,
            dropout,
            float(model["temperature_init"]),
        )
        self.mmtb = MissingModalityTopologyBinding(
            width,
            hidden,
            int(model["relation_count"]),
            int(model["graph_layers"]),
            int(model["router_top_k"]),
            dropout,
            bool(model.get("uniform_router", False)),
            str(model.get("graph_replacement", "none")),
        )
        self.aecr = EvidenceCalibrationHead(width, classes)
        self.softmax_head = nn.Linear(width * 2, classes)

    def project_inputs(
        self,
        image_embedding: torch.Tensor,
        text_embedding: torch.Tensor,
        text_mask: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        image = self.image_projection(image_embedding)
        mask = text_mask.reshape(-1, 1)
        text_projected = self.text_projection(text_embedding)
        text = mask * text_projected + (1.0 - mask) * self.missing_text
        return image, text

    def forward(
        self,
        image_embedding: torch.Tensor,
        text_embedding: torch.Tensor,
        text_mask: torch.Tensor,
        visual_prototypes: torch.Tensor,
        textual_prototypes: torch.Tensor,
        nearest_prototype_index: torch.Tensor,
        local_nodes: torch.Tensor,
        relation_ids: torch.Tensor,
        node_mask: torch.Tensor,
        neighbor_embeddings: torch.Tensor,
        neighbor_label_prototypes: torch.Tensor,
        grl_scale: float,
    ) -> AIGEROutput:
        image, text = self.project_inputs(image_embedding, text_embedding, text_mask)
        prototypes = self.prototype_gate(visual_prototypes, textual_prototypes)
        nearest = prototypes[nearest_prototype_index]
        style_code = self.casd.encode(image, text, text_mask)
        preliminary = torch.softmax(self.preliminary_head(style_code), dim=-1)
        preliminary_entropy = -torch.sum(
            preliminary * preliminary.clamp_min(1.0e-8).log(), dim=-1
        ) / torch.log(torch.tensor(float(self.num_classes), device=preliminary.device))
        query, router_weights, routing_loss = self.mmtb(
            image,
            text,
            text_mask,
            nearest,
            local_nodes,
            relation_ids,
            node_mask,
            preliminary_entropy,
        )
        summary, retrieval_weights = self.aecr.aggregate(
            query, neighbor_embeddings, neighbor_label_prototypes
        )
        logits = None
        if self.output_head == "softmax_cross_entropy":
            logits = self.softmax_head(torch.cat([query, summary], dim=-1))
            probabilities = torch.softmax(logits, dim=-1)
            evidence = probabilities
            alpha = probabilities + 1.0
            uncertainty = 1.0 - probabilities.max(dim=-1).values
        elif self.output_head == "evidential":
            evidence, alpha, probabilities, uncertainty = self.aecr(query, summary)
        else:
            raise ValueError(f"unsupported output head: {self.output_head}")
        artist_logits = self.casd.artist_logits(style_code, grl_scale)
        return AIGEROutput(
            probabilities=probabilities,
            alpha=alpha,
            evidence=evidence,
            uncertainty=uncertainty,
            query=l2_normalize(query),
            style_code=style_code,
            artist_logits=artist_logits,
            router_weights=router_weights,
            retrieval_weights=retrieval_weights,
            routing_loss=routing_loss,
            logits=logits,
        )

