from __future__ import annotations

import torch
import torch.nn.functional as functional
from torch import nn

from .layers import MLP, gradient_reverse, l2_normalize


class CrossArtistStyleDisentanglement(nn.Module):
    def __init__(
        self,
        task_width: int,
        hidden_width: int,
        num_artists: int,
        dropout: float,
        temperature: float,
    ):
        super().__init__()
        self.projector = MLP(task_width * 2 + 1, task_width, hidden_width, dropout)
        self.artist_classifier = nn.Sequential(
            nn.Linear(task_width, hidden_width // 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_width // 2, num_artists),
        )
        self.log_temperature = nn.Parameter(torch.tensor(float(temperature)).log())

    def encode(self, image: torch.Tensor, text: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        if mask.ndim == 1:
            mask = mask.unsqueeze(-1)
        return l2_normalize(self.projector(torch.cat([image, text, mask], dim=-1)))

    def artist_logits(self, style_code: torch.Tensor, grl_scale: float) -> torch.Tensor:
        return self.artist_classifier(gradient_reverse(style_code, grl_scale))

    def cross_artist_contrastive_loss(
        self,
        style_code: torch.Tensor,
        style_id: torch.Tensor,
        artist_index: torch.Tensor,
    ) -> torch.Tensor:
        logits = style_code @ style_code.T / self.log_temperature.exp().clamp_min(1.0e-4)
        diagonal = torch.eye(len(style_code), dtype=torch.bool, device=style_code.device)
        admissible = ~diagonal
        positives = (
            style_id[:, None].eq(style_id[None, :])
            & artist_index[:, None].ne(artist_index[None, :])
            & admissible
        )
        valid = positives.any(dim=1)
        if not valid.any():
            return logits.sum() * 0.0
        masked_logits = logits.masked_fill(~admissible, float("-inf"))
        log_prob = masked_logits - torch.logsumexp(masked_logits, dim=1, keepdim=True)
        positive_count = positives.sum(dim=1).clamp_min(1)
        per_anchor = -(log_prob.masked_fill(~positives, 0.0).sum(dim=1) / positive_count)
        return per_anchor[valid].mean()

    @staticmethod
    def artist_loss(logits: torch.Tensor, artist_index: torch.Tensor) -> torch.Tensor:
        return functional.cross_entropy(logits, artist_index)

