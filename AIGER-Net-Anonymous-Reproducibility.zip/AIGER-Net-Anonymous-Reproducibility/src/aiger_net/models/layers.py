from __future__ import annotations

import torch
from torch import nn
from torch.autograd import Function


class _GradientReverse(Function):
    @staticmethod
    def forward(ctx, value: torch.Tensor, scale: float) -> torch.Tensor:
        ctx.scale = scale
        return value.view_as(value)

    @staticmethod
    def backward(ctx, gradient: torch.Tensor):
        return -ctx.scale * gradient, None


def gradient_reverse(value: torch.Tensor, scale: float) -> torch.Tensor:
    return _GradientReverse.apply(value, scale)


class MLP(nn.Module):
    def __init__(self, input_width: int, output_width: int, hidden_width: int, dropout: float):
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(input_width, hidden_width),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_width, output_width),
            nn.LayerNorm(output_width),
        )

    def forward(self, value: torch.Tensor) -> torch.Tensor:
        return self.network(value)


def l2_normalize(value: torch.Tensor, epsilon: float = 1.0e-8) -> torch.Tensor:
    return value / value.norm(dim=-1, keepdim=True).clamp_min(epsilon)

