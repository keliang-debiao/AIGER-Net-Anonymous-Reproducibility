from __future__ import annotations

import numpy as np


class APSCalibrator:
    def __init__(self, target_coverage: float = 0.90, seed: int = 29):
        self.target_coverage = target_coverage
        self.seed = int(seed)
        self.quantile: float | None = None

    def nonconformity(self, probabilities: np.ndarray, targets: np.ndarray) -> np.ndarray:
        probs = np.asarray(probabilities, dtype=float)
        labels = np.asarray(targets, dtype=int)
        order = np.argsort(-probs, axis=1)
        sorted_probs = np.take_along_axis(probs, order, axis=1)
        cumulative = np.cumsum(sorted_probs, axis=1)
        ranks = np.argmax(order == labels[:, None], axis=1)
        selected = sorted_probs[np.arange(len(labels)), ranks]
        cumulative_before = cumulative[np.arange(len(labels)), ranks] - selected
        randomization = np.random.default_rng(self.seed).uniform(size=len(labels))
        return cumulative_before + randomization * selected

    def fit(self, probabilities: np.ndarray, targets: np.ndarray) -> "APSCalibrator":
        scores = self.nonconformity(probabilities, targets)
        n = len(scores)
        level = min(1.0, np.ceil((n + 1) * self.target_coverage) / n)
        self.quantile = float(np.quantile(scores, level, method="higher"))
        return self

    def sets(self, probabilities: np.ndarray, seed: int | None = None) -> np.ndarray:
        if self.quantile is None:
            raise RuntimeError("APS calibrator has not been fitted")
        probs = np.asarray(probabilities, dtype=float)
        order = np.argsort(-probs, axis=1)
        sorted_probs = np.take_along_axis(probs, order, axis=1)
        cumulative = np.cumsum(sorted_probs, axis=1)
        randomization = np.random.default_rng(self.seed if seed is None else seed).uniform(
            size=(len(probs), 1)
        )
        include_sorted = cumulative - randomization * sorted_probs <= self.quantile
        include_sorted[:, 0] = True
        output = np.zeros_like(include_sorted, dtype=bool)
        np.put_along_axis(output, order, include_sorted, axis=1)
        return output

