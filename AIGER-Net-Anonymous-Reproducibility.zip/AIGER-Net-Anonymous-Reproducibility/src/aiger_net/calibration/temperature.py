from __future__ import annotations

import numpy as np
from scipy.optimize import minimize_scalar


class TemperatureScaler:
    def __init__(self, epsilon: float = 1.0e-12):
        self.temperature = 1.0
        self.epsilon = epsilon

    def transform(self, probabilities: np.ndarray) -> np.ndarray:
        probs = np.asarray(probabilities, dtype=np.float64)
        logits = np.log(np.clip(probs, self.epsilon, 1.0)) / self.temperature
        logits -= logits.max(axis=1, keepdims=True)
        exp = np.exp(logits)
        return exp / exp.sum(axis=1, keepdims=True)

    def fit(self, probabilities: np.ndarray, targets: np.ndarray) -> "TemperatureScaler":
        probs = np.asarray(probabilities, dtype=np.float64)
        labels = np.asarray(targets, dtype=int)

        def objective(log_temperature: float) -> float:
            self.temperature = float(np.exp(log_temperature))
            calibrated = self.transform(probs)
            return float(-np.log(np.clip(calibrated[np.arange(len(labels)), labels], self.epsilon, 1)).mean())

        result = minimize_scalar(objective, bounds=(-3.0, 3.0), method="bounded")
        self.temperature = float(np.exp(result.x))
        return self

