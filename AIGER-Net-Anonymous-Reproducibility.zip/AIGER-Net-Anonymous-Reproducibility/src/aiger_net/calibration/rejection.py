from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class RejectionRule:
    max_set_size: int
    max_uncertainty: float
    min_confidence: float

    def rejected(
        self,
        probabilities: np.ndarray,
        uncertainty: np.ndarray,
        prediction_sets: np.ndarray,
    ) -> np.ndarray:
        return (
            (prediction_sets.sum(axis=1) > self.max_set_size)
            | (np.asarray(uncertainty) > self.max_uncertainty)
            | (np.asarray(probabilities).max(axis=1) < self.min_confidence)
        )


def select_rejection_rule(
    probabilities: np.ndarray,
    targets: np.ndarray,
    uncertainty: np.ndarray,
    prediction_sets: np.ndarray,
    size_grid: list[int],
    uncertainty_grid: list[float],
    confidence_grid: list[float],
    min_coverage: float,
    coverage_penalty: float,
) -> RejectionRule:
    predicted = np.asarray(probabilities).argmax(axis=1)
    correct = predicted == np.asarray(targets)
    candidates: list[tuple[float, float, int, RejectionRule]] = []
    for size in size_grid:
        for uncertainty_limit in uncertainty_grid:
            for confidence in confidence_grid:
                rule = RejectionRule(size, uncertainty_limit, confidence)
                kept = ~rule.rejected(probabilities, uncertainty, prediction_sets)
                coverage = float(kept.mean())
                if coverage < min_coverage or not kept.any():
                    continue
                selective_error = float(1.0 - correct[kept].mean())
                objective = selective_error + coverage_penalty * (1.0 - coverage)
                candidates.append((objective, -coverage, size, rule))
    if not candidates:
        raise RuntimeError("no rejection rule satisfies minimum coverage")
    return min(candidates, key=lambda item: (item[0], item[1], item[2]))[-1]

