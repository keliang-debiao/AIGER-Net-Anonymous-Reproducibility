from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from .calibration import APSCalibrator, TemperatureScaler
from .metrics import classification_metrics, partial_label_metrics


def evaluate_internal(
    probabilities: np.ndarray,
    targets: np.ndarray,
    calibration_probabilities: np.ndarray,
    calibration_targets: np.ndarray,
    target_coverage: float,
    ece_bins: int,
    seed: int = 29,
) -> tuple[dict[str, float], np.ndarray, TemperatureScaler, APSCalibrator]:
    temperature = TemperatureScaler().fit(calibration_probabilities, calibration_targets)
    calibration_scaled = temperature.transform(calibration_probabilities)
    evaluation_scaled = temperature.transform(probabilities)
    aps = APSCalibrator(target_coverage, seed=seed).fit(calibration_scaled, calibration_targets)
    sets = aps.sets(evaluation_scaled, seed=seed + 1)
    metrics = classification_metrics(evaluation_scaled, targets, ece_bins)
    metrics["aps_coverage"] = float(sets[np.arange(len(targets)), targets].mean())
    metrics["aps_mean_size"] = float(sets.sum(axis=1).mean())
    return metrics, sets, temperature, aps


def evaluate_external(
    probabilities: np.ndarray,
    movement_sets: list[set[int]],
    aps: APSCalibrator,
    ece_bins: int,
) -> tuple[dict[str, float], np.ndarray]:
    sets = aps.sets(probabilities)
    return partial_label_metrics(probabilities, movement_sets, sets, ece_bins), sets


def load_prediction_bundle(path: str | Path) -> tuple[pd.DataFrame, np.ndarray]:
    source = Path(path)
    frame = pd.read_parquet(source.with_suffix(".parquet"))
    probabilities = np.load(source.with_suffix(".npy"))
    if len(frame) != len(probabilities):
        raise ValueError("prediction metadata and probability rows differ")
    return frame, probabilities

