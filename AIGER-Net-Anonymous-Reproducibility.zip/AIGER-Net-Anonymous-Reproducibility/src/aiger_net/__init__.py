"""AIGER-Net reproduction package."""

__version__ = "1.0.0"

