from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable

import pandas as pd


def load_records(paths: Iterable[str | Path], allow_reference_only: bool = False) -> list[dict]:
    records: list[dict] = []
    for path in paths:
        with Path(path).open("r", encoding="utf-8") as handle:
            payload = json.load(handle)
        status = payload.get("record_status")
        if status == "reference-only" and not allow_reference_only:
            raise RuntimeError(
                f"reference-only record cannot enter an empirical report: {path}"
            )
        if status not in {"empirical", "reference-only"}:
            raise ValueError(f"invalid record status in {path}")
        records.append(payload)
    return records


def metrics_frame(records: list[dict]) -> pd.DataFrame:
    rows = []
    for record in records:
        base = {
            "run_id": record["run_id"],
            "stage": record["stage"],
            "seed": record["seed"],
            "outer_fold": record.get("outer_fold"),
            "record_status": record["record_status"],
        }
        rows.append({**base, **record.get("metrics", {})})
    return pd.DataFrame(rows)

