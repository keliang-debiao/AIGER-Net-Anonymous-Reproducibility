from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from .audit import (
    duplicate_components,
    file_sha256,
    image_files,
    inspect_image,
    normalize_token,
    sanitize_text,
)


def _read_tables(root: Path) -> list[tuple[Path, pd.DataFrame]]:
    tables = []
    for path in sorted(root.rglob("*.csv")):
        try:
            tables.append((path, pd.read_csv(path)))
        except (UnicodeDecodeError, pd.errors.ParserError):
            continue
    for path in sorted(root.rglob("*.json")):
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(payload, list) and payload and isinstance(payload[0], dict):
                tables.append((path, pd.DataFrame(payload)))
        except (UnicodeDecodeError, json.JSONDecodeError):
            continue
    return tables


def _column(frame: pd.DataFrame, candidates: list[str], required: bool = True) -> str | None:
    lowered = {str(column).casefold(): str(column) for column in frame.columns}
    for candidate in candidates:
        if candidate.casefold() in lowered:
            return lowered[candidate.casefold()]
    if required:
        raise KeyError(f"none of the required columns is present: {candidates}")
    return None


def _select_table(root: Path, required_groups: list[list[str]]) -> tuple[Path, pd.DataFrame]:
    candidates = []
    for path, frame in _read_tables(root):
        score = sum(
            any(candidate.casefold() in {str(c).casefold() for c in frame.columns} for candidate in group)
            for group in required_groups
        )
        candidates.append((score, len(frame), path, frame))
    if not candidates or max(item[0] for item in candidates) < len(required_groups):
        raise FileNotFoundError(f"no metadata table under {root} contains the required fields")
    _, _, path, frame = max(candidates, key=lambda item: (item[0], item[1]))
    return path, frame


def _image_lookup(root: Path) -> dict[str, list[Path]]:
    lookup: dict[str, list[Path]] = {}
    for path in image_files(root):
        lookup.setdefault(path.name.casefold(), []).append(path)
        lookup.setdefault(path.stem.casefold(), []).append(path)
    return lookup


def _resolve_image(root: Path, lookup: dict[str, list[Path]], value: object) -> Path:
    token = str(value).strip()
    direct = root / token
    if direct.is_file():
        return direct
    for key in (Path(token).name.casefold(), Path(token).stem.casefold()):
        matches = lookup.get(key, [])
        if len(matches) == 1:
            return matches[0]
    raise FileNotFoundError(f"cannot resolve image path from metadata value: {token}")


def _label_lookup(label_map_path: str | Path) -> tuple[dict[str, tuple[int, str]], dict[str, str]]:
    table = pd.read_csv(label_map_path)
    development: dict[str, tuple[int, str]] = {}
    aliases: dict[str, str] = {}
    for row in table.itertuples(index=False):
        normalized = str(row.normalized_label)
        development[normalize_token(row.development_label)] = (int(row.style_id), normalized)
        development[normalized] = (int(row.style_id), normalized)
        aliases[normalized] = normalized
        for alias in str(row.external_aliases).split("|"):
            aliases[normalize_token(alias)] = normalized
    return development, aliases


def build_wikiart_manifest(
    root: str | Path,
    label_map_path: str | Path,
    external_artist_ids: set[str],
    min_alpha_tokens: int,
    phash_threshold: int,
    cosine_threshold: float,
) -> pd.DataFrame:
    root = Path(root)
    _, metadata = _select_table(
        root,
        [["artist", "artist_name"], ["genre", "style"], ["filename", "file", "path", "image"]],
    )
    artist_col = _column(metadata, ["artist", "artist_name", "painter"])
    style_col = _column(metadata, ["genre", "style", "movement"])
    file_col = _column(metadata, ["filename", "file", "path", "image"])
    description_col = _column(metadata, ["description", "text", "caption", "title"], required=False)
    lookup = _image_lookup(root)
    label_lookup, _ = _label_lookup(label_map_path)
    artist_lexicon = {str(value).strip() for value in metadata[artist_col].dropna().unique()}
    style_lexicon = {str(value).strip() for value in metadata[style_col].dropna().unique()}
    rows = []
    for source_index, row in metadata.iterrows():
        try:
            path = _resolve_image(root, lookup, row[file_col])
            sha = file_sha256(path)
            phash, width, height = inspect_image(path)
        except (FileNotFoundError, OSError):
            continue
        artist_raw = str(row[artist_col]).strip()
        style_raw = str(row[style_col]).strip()
        style_key = normalize_token(style_raw)
        style = label_lookup.get(style_key)
        clean, available = sanitize_text(
            row[description_col] if description_col else "",
            artist_lexicon,
            style_lexicon,
            [path.stem],
            min_alpha_tokens,
        )
        artist_id = normalize_token(artist_raw)
        work_id = f"wikiart:{sha[:20]}"
        rows.append(
            {
                "work_id": work_id,
                "dataset_id": "wikiart",
                "relative_path": str(path.relative_to(root)),
                "sha256": sha,
                "phash64": phash,
                "artist_raw": artist_raw,
                "artist_id": artist_id,
                "style_raw": style_raw,
                "style_id": style[0] if style else None,
                "style_name": style[1] if style else None,
                "description_raw": str(row[description_col]) if description_col else "",
                "description_clean": clean,
                "text_available": available,
                "width": width,
                "height": height,
                "source_subset": str(path.parent.relative_to(root)),
                "source_row": int(source_index),
                "external_artist_overlap": int(artist_id in external_artist_ids),
            }
        )
    frame = pd.DataFrame(rows)
    frame["eligible_primary"] = (
        frame["style_id"].notna() & frame["external_artist_overlap"].eq(0)
    ).astype(int)
    frame["eligible_harmonized"] = frame["eligible_primary"]
    frame["duplicate_component"] = duplicate_components(
        frame, phash_threshold, cosine_threshold
    )
    return frame


def build_external_manifest(
    root: str | Path,
    label_map_path: str | Path,
    phash_threshold: int,
    cosine_threshold: float,
) -> pd.DataFrame:
    root = Path(root)
    tables = _read_tables(root)
    artist_metadata = None
    for _, frame in tables:
        columns = {str(column).casefold() for column in frame.columns}
        if columns & {"name", "artist", "artist_name"} and columns & {"genre", "genres", "movement", "movements"}:
            artist_metadata = frame
            break
    if artist_metadata is None:
        raise FileNotFoundError("external artist metadata with movement tags was not found")
    artist_col = _column(artist_metadata, ["name", "artist", "artist_name"])
    movement_col = _column(artist_metadata, ["genre", "genres", "movement", "movements"])
    _, alias_lookup = _label_lookup(label_map_path)
    artist_movements: dict[str, list[str]] = {}
    for _, row in artist_metadata.iterrows():
        artist = normalize_token(row[artist_col])
        raw = str(row[movement_col])
        tokens = re_split_movements(raw)
        mapped = sorted({alias_lookup[token] for token in tokens if token in alias_lookup})
        artist_movements[artist] = mapped
    rows = []
    for path in image_files(root):
        artist_raw = path.parent.name
        artist_id = normalize_token(artist_raw)
        movement_set = artist_movements.get(artist_id, [])
        try:
            sha = file_sha256(path)
            phash, width, height = inspect_image(path)
        except OSError:
            continue
        rows.append(
            {
                "work_id": f"best_artworks:{sha[:20]}",
                "dataset_id": "best_artworks",
                "relative_path": str(path.relative_to(root)),
                "sha256": sha,
                "phash64": phash,
                "artist_raw": artist_raw,
                "artist_id": artist_id,
                "movement_set": "|".join(movement_set),
                "movement_count": len(movement_set),
                "description_raw": "",
                "description_clean": "",
                "text_available": 0,
                "width": width,
                "height": height,
                "source_subset": str(path.parent.relative_to(root)),
                "eligible_primary": int(len(movement_set) > 0),
                "eligible_harmonized": int(len(movement_set) > 0),
            }
        )
    frame = pd.DataFrame(rows)
    frame["duplicate_component"] = duplicate_components(
        frame, phash_threshold, cosine_threshold
    )
    return frame


def re_split_movements(value: str) -> list[str]:
    import re

    normalized = value.replace("[", " ").replace("]", " ").replace("'", " ").replace('"', " ")
    return [normalize_token(token) for token in re.split(r"[,;/|]", normalized) if token.strip()]

