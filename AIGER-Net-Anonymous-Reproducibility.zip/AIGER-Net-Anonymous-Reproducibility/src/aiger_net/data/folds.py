from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedGroupKFold

from .audit import DisjointSet


def leakage_safe_groups(frame: pd.DataFrame) -> pd.Series:
    artists = frame["artist_id"].astype(str).tolist()
    duplicates = frame["duplicate_component"].astype(str).tolist()
    nodes = [f"artist:{a}" for a in artists] + [f"dup:{d}" for d in duplicates]
    dsu = DisjointSet(nodes)
    for artist, duplicate in zip(artists, duplicates, strict=True):
        dsu.union(f"artist:{artist}", f"dup:{duplicate}")
    roots = [dsu.find(f"artist:{artist}") for artist in artists]
    root_to_id = {root: f"group_{idx:05d}" for idx, root in enumerate(sorted(set(roots)))}
    return pd.Series([root_to_id[root] for root in roots], index=frame.index)


def assign_outer_folds(frame: pd.DataFrame, n_splits: int = 5, seed: int = 29) -> pd.DataFrame:
    required = {"style_id", "artist_id", "duplicate_component"}
    missing = sorted(required - set(frame.columns))
    if missing:
        raise KeyError(f"fold assignment requires columns: {missing}")
    output = frame.copy()
    groups = leakage_safe_groups(output)
    splitter = StratifiedGroupKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    output["outer_fold"] = -1
    x = np.zeros((len(output), 1), dtype=np.float32)
    for fold, (_, valid) in enumerate(splitter.split(x, output["style_id"], groups)):
        output.iloc[valid, output.columns.get_loc("outer_fold")] = fold
    if (output["outer_fold"] < 0).any():
        raise RuntimeError("at least one row lacks an outer fold")
    assert_no_boundary_leakage(output)
    return output


def calibration_artists(
    training_frame: pd.DataFrame,
    fraction: float = 0.10,
    seed: int = 29,
) -> set[str]:
    artist_targets = (
        training_frame.groupby("artist_id")["style_id"]
        .agg(lambda values: int(values.value_counts().index[0]))
        .reset_index()
    )
    splitter = StratifiedGroupKFold(
        n_splits=max(2, round(1.0 / fraction)), shuffle=True, random_state=seed
    )
    x = np.zeros((len(artist_targets), 1), dtype=np.float32)
    _, calibration = next(
        splitter.split(x, artist_targets["style_id"], artist_targets["artist_id"])
    )
    return set(artist_targets.iloc[calibration]["artist_id"].astype(str))


def assert_no_boundary_leakage(frame: pd.DataFrame) -> None:
    for field in ("artist_id", "duplicate_component"):
        fold_counts = frame.groupby(field)["outer_fold"].nunique()
        offenders = fold_counts[fold_counts > 1]
        if not offenders.empty:
            raise AssertionError(f"{field} crosses outer folds: {offenders.index[:5].tolist()}")


@dataclass(frozen=True)
class FoldView:
    train: pd.DataFrame
    calibration: pd.DataFrame
    validation: pd.DataFrame


def fold_view(frame: pd.DataFrame, outer_fold: int, calibration_fraction: float, seed: int) -> FoldView:
    validation = frame.loc[frame["outer_fold"] == outer_fold].copy()
    outer_training = frame.loc[frame["outer_fold"] != outer_fold].copy()
    held_out = calibration_artists(outer_training, calibration_fraction, seed + outer_fold)
    calibration = outer_training.loc[outer_training["artist_id"].astype(str).isin(held_out)].copy()
    train = outer_training.loc[~outer_training["artist_id"].astype(str).isin(held_out)].copy()
    if set(train["artist_id"]) & set(calibration["artist_id"]):
        raise AssertionError("calibration artists overlap model-fitting artists")
    return FoldView(train=train, calibration=calibration, validation=validation)

