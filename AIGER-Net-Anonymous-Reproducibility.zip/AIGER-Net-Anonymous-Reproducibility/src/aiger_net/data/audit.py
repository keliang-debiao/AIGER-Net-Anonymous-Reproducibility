from __future__ import annotations

import hashlib
import re
import unicodedata
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd
from PIL import Image


IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff"}


def normalize_token(value: object) -> str:
    text = unicodedata.normalize("NFKC", str(value or "")).casefold().strip()
    text = re.sub(r"[^\w]+", "_", text, flags=re.UNICODE)
    return re.sub(r"_+", "_", text).strip("_")


def image_files(root: str | Path) -> list[Path]:
    base = Path(root)
    return sorted(path for path in base.rglob("*") if path.suffix.casefold() in IMAGE_SUFFIXES)


def file_sha256(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def inspect_image(path: str | Path) -> tuple[str, int, int]:
    import imagehash

    with Image.open(path) as image:
        rgb = image.convert("RGB")
        return str(imagehash.phash(rgb, hash_size=8)), rgb.width, rgb.height


def sanitize_text(
    text: object,
    artist_lexicon: set[str],
    style_lexicon: set[str],
    filename_tokens: Iterable[str] = (),
    min_alpha_tokens: int = 3,
) -> tuple[str, int]:
    value = unicodedata.normalize("NFKC", str(text or ""))
    value = re.sub(r"https?://\S+|www\.\S+", " ", value, flags=re.IGNORECASE)
    value = re.sub(r"\b(?:1[0-9]{3}|20[0-9]{2})\b", " ", value)
    locked = sorted(
        {term for term in artist_lexicon | style_lexicon | set(filename_tokens) if term},
        key=len,
        reverse=True,
    )
    for term in locked:
        value = re.sub(rf"(?<!\w){re.escape(term)}(?!\w)", " ", value, flags=re.IGNORECASE)
    value = re.sub(r"\b(?:wikiart|repository|download|image|painting by)\b", " ", value, flags=re.I)
    value = re.sub(r"\s+", " ", value).strip()
    tokens = re.findall(r"[A-Za-z]+", value)
    return (value, 1) if len(tokens) >= min_alpha_tokens else ("", 0)


class DisjointSet:
    def __init__(self, items: Iterable[str]):
        self.parent = {item: item for item in items}
        self.rank = {item: 0 for item in items}

    def find(self, item: str) -> str:
        parent = self.parent[item]
        if parent != item:
            self.parent[item] = self.find(parent)
        return self.parent[item]

    def union(self, left: str, right: str) -> None:
        a, b = self.find(left), self.find(right)
        if a == b:
            return
        if self.rank[a] < self.rank[b]:
            a, b = b, a
        self.parent[b] = a
        if self.rank[a] == self.rank[b]:
            self.rank[a] += 1


def hamming_hex(left: str, right: str) -> int:
    return (int(left, 16) ^ int(right, 16)).bit_count()


def duplicate_components(
    manifest: pd.DataFrame,
    phash_threshold: int,
    cosine_threshold: float,
    embedding_column: str = "embedding",
) -> pd.Series:
    ids = manifest["work_id"].astype(str).tolist()
    dsu = DisjointSet(ids)
    for _, group in manifest.groupby("sha256", sort=False):
        group_ids = group["work_id"].astype(str).tolist()
        for item in group_ids[1:]:
            dsu.union(group_ids[0], item)

    buckets: dict[str, list[int]] = defaultdict(list)
    hashes = manifest["phash64"].astype(str).tolist()
    for index, phash in enumerate(hashes):
        for offset in range(0, 16, 4):
            buckets[f"{offset}:{phash[offset:offset + 4]}"].append(index)

    visited: set[tuple[int, int]] = set()
    for members in buckets.values():
        for pos, left in enumerate(members):
            for right in members[pos + 1 :]:
                pair = (min(left, right), max(left, right))
                if pair in visited:
                    continue
                visited.add(pair)
                if hamming_hex(hashes[left], hashes[right]) > phash_threshold:
                    continue
                confirmed = False
                if embedding_column in manifest.columns:
                    a = np.asarray(manifest.iloc[left][embedding_column], dtype=float)
                    b = np.asarray(manifest.iloc[right][embedding_column], dtype=float)
                    denom = np.linalg.norm(a) * np.linalg.norm(b)
                    confirmed = bool(denom and float(a @ b / denom) >= cosine_threshold)
                if confirmed:
                    dsu.union(ids[left], ids[right])
    roots = [dsu.find(item) for item in ids]
    root_map = {root: f"dup_{idx:06d}" for idx, root in enumerate(sorted(set(roots)))}
    return pd.Series([root_map[root] for root in roots], index=manifest.index)


@dataclass(frozen=True)
class AuditSummary:
    rows: int
    distinct_artists: int
    distinct_styles: int
    exact_duplicate_groups: int
    duplicate_components: int
    text_available_rate: float


def summarize_manifest(frame: pd.DataFrame) -> AuditSummary:
    exact_groups = int((frame.groupby("sha256").size() > 1).sum())
    return AuditSummary(
        rows=len(frame),
        distinct_artists=int(frame["artist_id"].nunique()),
        distinct_styles=int(frame["style_id"].nunique()) if "style_id" in frame else 0,
        exact_duplicate_groups=exact_groups,
        duplicate_components=int(frame["duplicate_component"].nunique()),
        text_available_rate=float(frame["text_available"].mean()),
    )

