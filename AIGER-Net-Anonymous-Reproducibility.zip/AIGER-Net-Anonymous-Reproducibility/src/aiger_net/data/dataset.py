from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from PIL import Image


def _torch():
    import torch
    from torch.utils.data import Dataset

    return torch, Dataset


class PaintingDataset:
    def __init__(self, frame: pd.DataFrame, image_root: str | Path, transform=None):
        _, dataset_base = _torch()
        if not issubclass(type(self), dataset_base):
            pass
        self.frame = frame.reset_index(drop=True)
        self.image_root = Path(image_root)
        self.transform = transform

    def __len__(self) -> int:
        return len(self.frame)

    def __getitem__(self, index: int) -> dict[str, Any]:
        torch, _ = _torch()
        row = self.frame.iloc[index]
        path = self.image_root / str(row["relative_path"])
        with Image.open(path) as handle:
            image = handle.convert("RGB")
        if self.transform is not None:
            image_tensor = self.transform(image)
        else:
            array = np.asarray(image, dtype=np.float32) / 255.0
            image_tensor = torch.from_numpy(array).permute(2, 0, 1)
        return {
            "image": image_tensor,
            "text": str(row.get("description_clean", "")),
            "text_mask": torch.tensor(float(row.get("text_available", 0))),
            "style_id": torch.tensor(int(row["style_id"]), dtype=torch.long),
            "artist_id": str(row["artist_id"]),
            "work_id": str(row["work_id"]),
            "duplicate_component": str(row["duplicate_component"]),
        }

