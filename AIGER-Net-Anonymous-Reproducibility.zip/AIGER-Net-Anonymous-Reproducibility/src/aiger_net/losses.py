from __future__ import annotations

import torch
import torch.nn.functional as functional


def dirichlet_kl(alpha: torch.Tensor) -> torch.Tensor:
    classes = alpha.shape[-1]
    prior = torch.ones_like(alpha)
    sum_alpha = alpha.sum(dim=-1, keepdim=True)
    sum_prior = prior.sum(dim=-1, keepdim=True)
    first = (
        torch.lgamma(sum_alpha)
        - torch.lgamma(alpha).sum(dim=-1, keepdim=True)
        - torch.lgamma(sum_prior)
        + torch.lgamma(prior).sum(dim=-1, keepdim=True)
    )
    second = ((alpha - prior) * (torch.digamma(alpha) - torch.digamma(sum_alpha))).sum(
        dim=-1, keepdim=True
    )
    return (first + second).reshape(-1)


def evidential_loss(
    alpha: torch.Tensor,
    targets: torch.Tensor,
    kl_weight: float,
) -> torch.Tensor:
    one_hot = functional.one_hot(targets, num_classes=alpha.shape[-1]).to(alpha.dtype)
    strength = alpha.sum(dim=-1, keepdim=True)
    data_term = torch.sum(one_hot * (torch.digamma(strength) - torch.digamma(alpha)), dim=-1)
    adjusted = one_hot + (1.0 - one_hot) * alpha
    return (data_term + kl_weight * dirichlet_kl(adjusted)).mean()


def binding_loss(
    image: torch.Tensor,
    text: torch.Tensor,
    text_mask: torch.Tensor,
    query: torch.Tensor,
    target_prototype: torch.Tensor,
) -> torch.Tensor:
    mask = text_mask.reshape(-1).to(image.dtype)
    text_distance = 1.0 - functional.cosine_similarity(image, text, dim=-1)
    text_term = (mask * text_distance).sum() / mask.sum().clamp_min(1.0)
    prototype_term = (1.0 - functional.cosine_similarity(query, target_prototype, dim=-1)).mean()
    return text_term + prototype_term


def complete_loss(
    model,
    output,
    targets: torch.Tensor,
    artist_index: torch.Tensor,
    image: torch.Tensor,
    text: torch.Tensor,
    text_mask: torch.Tensor,
    target_prototype: torch.Tensor,
    config: dict,
    epoch: int,
) -> tuple[torch.Tensor, dict[str, float]]:
    weights = config["loss"]
    kl_weight = min(1.0, epoch / max(1, int(weights["evidence_kl_warmup_epochs"])))
    if getattr(model, "output_head", "evidential") == "softmax_cross_entropy":
        edl = functional.cross_entropy(output.logits, targets)
    else:
        edl = evidential_loss(output.alpha, targets, kl_weight)
    contrast = output.style_code.sum() * 0.0
    if float(weights["lambda_cross_artist"]) > 0:
        contrast = model.casd.cross_artist_contrastive_loss(
            output.style_code, targets, artist_index
        )
    artist = functional.cross_entropy(output.artist_logits, artist_index)
    bind = binding_loss(image, text, text_mask, output.query, target_prototype)
    total = (
        edl
        + float(weights["lambda_cross_artist"]) * contrast
        + float(weights["lambda_binding"]) * bind
        + float(weights["lambda_router"]) * output.routing_loss
        + float(weights["lambda_artist"]) * artist
    )
    parts = {
        "total": float(total.detach()),
        "edl": float(edl.detach()),
        "cross_artist": float(contrast.detach()),
        "binding": float(bind.detach()),
        "routing": float(output.routing_loss.detach()),
        "artist": float(artist.detach()),
    }
    return total, parts

