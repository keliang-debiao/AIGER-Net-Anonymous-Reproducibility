from __future__ import annotations

import numpy as np
from sklearn.metrics import (
    balanced_accuracy_score,
    f1_score,
    log_loss,
    matthews_corrcoef,
)


def multiclass_brier(probabilities: np.ndarray, targets: np.ndarray) -> float:
    probs = np.asarray(probabilities, dtype=float)
    labels = np.asarray(targets, dtype=int)
    one_hot = np.eye(probs.shape[1])[labels]
    return float(np.mean(np.sum((probs - one_hot) ** 2, axis=1)))


def equal_mass_ece(
    probabilities: np.ndarray,
    correctness: np.ndarray,
    bins: int = 15,
) -> float:
    probs = np.asarray(probabilities, dtype=float)
    confidence = probs.max(axis=1)
    correct = np.asarray(correctness, dtype=float)
    order = np.argsort(confidence)
    groups = np.array_split(order, bins)
    total = len(confidence)
    return float(
        sum(
            (len(group) / total) * abs(correct[group].mean() - confidence[group].mean())
            for group in groups
            if len(group)
        )
    )


def aurc(probabilities: np.ndarray, correctness: np.ndarray) -> float:
    confidence = np.asarray(probabilities).max(axis=1)
    errors = 1.0 - np.asarray(correctness, dtype=float)
    order = np.argsort(-confidence)
    cumulative_risk = np.cumsum(errors[order]) / np.arange(1, len(order) + 1)
    return float(cumulative_risk.mean())


def classification_metrics(probabilities: np.ndarray, targets: np.ndarray, bins: int = 15) -> dict[str, float]:
    probs = np.asarray(probabilities, dtype=float)
    labels = np.asarray(targets, dtype=int)
    predicted = probs.argmax(axis=1)
    top3 = np.argpartition(-probs, kth=min(2, probs.shape[1] - 1), axis=1)[:, :3]
    correct = predicted == labels
    return {
        "macro_f1": float(f1_score(labels, predicted, average="macro")),
        "balanced_accuracy": float(balanced_accuracy_score(labels, predicted)),
        "mcc": float(matthews_corrcoef(labels, predicted)),
        "top1_accuracy": float(correct.mean()),
        "top3_accuracy": float(np.mean([label in row for label, row in zip(labels, top3, strict=True)])),
        "nll": float(log_loss(labels, probs, labels=np.arange(probs.shape[1]))),
        "brier": multiclass_brier(probs, labels),
        "ece": equal_mass_ece(probs, correct, bins),
        "aurc": aurc(probs, correct),
    }


def partial_label_metrics(
    probabilities: np.ndarray,
    admissible_sets: list[set[int]],
    prediction_sets: np.ndarray | None = None,
    bins: int = 15,
) -> dict[str, float]:
    probs = np.asarray(probabilities, dtype=float)
    predicted = probs.argmax(axis=1)
    top3 = np.argpartition(-probs, kth=min(2, probs.shape[1] - 1), axis=1)[:, :3]
    correct = np.array([pred in allowed for pred, allowed in zip(predicted, admissible_sets, strict=True)])
    set_probability = np.array(
        [probs[i, sorted(allowed)].sum() for i, allowed in enumerate(admissible_sets)]
    )
    output = {
        "set_hit_at_1": float(correct.mean()),
        "top3_coverage": float(
            np.mean([bool(set(row) & allowed) for row, allowed in zip(top3, admissible_sets, strict=True)])
        ),
        "set_nll": float(-np.log(np.clip(set_probability, 1.0e-12, 1.0)).mean()),
        "set_ece": equal_mass_ece(probs, correct, bins),
        "set_aurc": aurc(probs, correct),
    }
    if prediction_sets is not None:
        coverage = [
            bool(set(np.flatnonzero(prediction_sets[i])) & allowed)
            for i, allowed in enumerate(admissible_sets)
        ]
        output["aps_coverage"] = float(np.mean(coverage))
        output["aps_mean_size"] = float(prediction_sets.sum(axis=1).mean())
    return output

