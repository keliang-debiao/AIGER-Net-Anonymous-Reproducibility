from __future__ import annotations

from collections.abc import Callable

import numpy as np
from scipy import stats


def artist_cluster_bootstrap(
    artist_ids: np.ndarray,
    metric: Callable[[np.ndarray], float],
    replicates: int = 2000,
    seed: int = 29,
    confidence: float = 0.95,
) -> tuple[float, float, float]:
    artists = np.unique(np.asarray(artist_ids))
    by_artist = {artist: np.flatnonzero(np.asarray(artist_ids) == artist) for artist in artists}
    point = float(metric(np.arange(len(artist_ids))))
    rng = np.random.default_rng(seed)
    values = np.empty(replicates, dtype=float)
    for replicate in range(replicates):
        sampled = rng.choice(artists, size=len(artists), replace=True)
        indices = np.concatenate([by_artist[artist] for artist in sampled])
        values[replicate] = metric(indices)
    alpha = 1.0 - confidence
    lower, upper = np.quantile(values, [alpha / 2.0, 1.0 - alpha / 2.0])
    return point, float(lower), float(upper)


def matched_fold_contrast(left: np.ndarray, right: np.ndarray, confidence: float = 0.95):
    difference = np.asarray(left, dtype=float) - np.asarray(right, dtype=float)
    n = len(difference)
    mean = float(difference.mean())
    standard_error = float(difference.std(ddof=1) / np.sqrt(n))
    critical = float(stats.t.ppf(1.0 - (1.0 - confidence) / 2.0, df=n - 1))
    interval = (mean - critical * standard_error, mean + critical * standard_error)
    _, p_value = stats.ttest_1samp(difference, popmean=0.0)
    return mean, interval, float(p_value)


def holm_adjust(p_values: list[float]) -> list[float]:
    values = np.asarray(p_values, dtype=float)
    order = np.argsort(values)
    adjusted = np.empty_like(values)
    running = 0.0
    count = len(values)
    for rank, index in enumerate(order):
        candidate = min(1.0, (count - rank) * values[index])
        running = max(running, candidate)
        adjusted[index] = running
    return adjusted.tolist()

