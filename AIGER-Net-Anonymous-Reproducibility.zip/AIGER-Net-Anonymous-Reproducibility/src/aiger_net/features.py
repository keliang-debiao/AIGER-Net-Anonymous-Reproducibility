from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np


@dataclass
class FeatureStore:
    work_ids: np.ndarray
    image_embeddings: np.ndarray
    text_embeddings: np.ndarray
    text_mask: np.ndarray
    prompt_embeddings: np.ndarray

    @classmethod
    def load(cls, path: str | Path) -> "FeatureStore":
        payload = np.load(path, allow_pickle=False)
        return cls(
            work_ids=payload["work_ids"],
            image_embeddings=payload["image_embeddings"].astype(np.float32),
            text_embeddings=payload["text_embeddings"].astype(np.float32),
            text_mask=payload["text_mask"].astype(np.float32),
            prompt_embeddings=payload["prompt_embeddings"].astype(np.float32),
        )

    def save(self, path: str | Path) -> None:
        destination = Path(path)
        destination.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(
            destination,
            work_ids=self.work_ids,
            image_embeddings=self.image_embeddings,
            text_embeddings=self.text_embeddings,
            text_mask=self.text_mask,
            prompt_embeddings=self.prompt_embeddings,
        )


class OnlineFoundationEncoder:
    def __init__(self, model_name: str, device: str, trust_remote_code: bool = True):
        import torch
        from transformers import AutoModel, AutoProcessor

        self.torch = torch
        self.processor = AutoProcessor.from_pretrained(model_name, trust_remote_code=trust_remote_code)
        self.model = AutoModel.from_pretrained(
            model_name,
            trust_remote_code=trust_remote_code,
            torch_dtype=torch.float16 if device.startswith("cuda") else torch.float32,
        ).to(device)
        self.model.eval()
        for parameter in self.model.parameters():
            parameter.requires_grad_(False)
        self.device = device

    def _pool(self, output):
        torch = self.torch
        if hasattr(output, "pooler_output") and output.pooler_output is not None:
            return output.pooler_output
        if hasattr(output, "last_hidden_state"):
            return output.last_hidden_state.mean(dim=1)
        if isinstance(output, torch.Tensor):
            return output
        if isinstance(output, (tuple, list)) and output:
            return output[0].mean(dim=1) if output[0].ndim == 3 else output[0]
        raise TypeError("foundation output has no supported embedding field")

    @property
    def no_grad(self):
        return self.torch.no_grad()

    def encode_images(self, images: list) -> np.ndarray:
        inputs = self.processor(images=images, return_tensors="pt", padding=True)
        inputs = {key: value.to(self.device) for key, value in inputs.items()}
        with self.no_grad:
            if hasattr(self.model, "get_image_features"):
                values = self.model.get_image_features(**inputs)
            else:
                values = self._pool(self.model(**inputs))
        values = self.torch.nn.functional.normalize(values.float(), dim=-1)
        return values.cpu().numpy()

    def encode_texts(self, texts: list[str]) -> np.ndarray:
        inputs = self.processor(text=texts, return_tensors="pt", padding=True, truncation=True)
        inputs = {key: value.to(self.device) for key, value in inputs.items()}
        with self.no_grad:
            if hasattr(self.model, "get_text_features"):
                values = self.model.get_text_features(**inputs)
            else:
                values = self._pool(self.model(**inputs))
        values = self.torch.nn.functional.normalize(values.float(), dim=-1)
        return values.cpu().numpy()

