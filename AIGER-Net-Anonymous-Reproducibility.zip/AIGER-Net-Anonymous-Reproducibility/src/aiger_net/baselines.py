from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import RobustScaler


def sklearn_baseline(model_id: str, seed: int, parameters: dict | None = None):
    parameters = parameters or {}
    if model_id == "logistic_regression":
        estimator = LogisticRegression(
            C=float(parameters.get("C", 1.0)),
            class_weight=parameters.get("class_weight"),
            max_iter=2000,
            multi_class="auto",
            random_state=seed,
        )
    elif model_id == "random_forest":
        estimator = RandomForestClassifier(
            n_estimators=int(parameters.get("n_estimators", 600)),
            max_depth=parameters.get("max_depth"),
            max_features=float(parameters.get("max_features", 0.6)),
            class_weight="balanced_subsample",
            n_jobs=-1,
            random_state=seed,
        )
    elif model_id == "two_layer_mlp":
        estimator = MLPClassifier(
            hidden_layer_sizes=(int(parameters.get("hidden", 512)),) * 2,
            alpha=float(parameters.get("weight_decay", 1.0e-4)),
            batch_size=128,
            max_iter=200,
            early_stopping=True,
            random_state=seed,
        )
    else:
        raise KeyError(f"unsupported sklearn baseline: {model_id}")
    return Pipeline([("scale", RobustScaler()), ("model", estimator)])


def xgboost_baseline(seed: int, parameters: dict | None = None):
    from xgboost import XGBClassifier

    parameters = parameters or {}
    return XGBClassifier(
        n_estimators=int(parameters.get("n_estimators", 600)),
        max_depth=int(parameters.get("max_depth", 7)),
        learning_rate=float(parameters.get("learning_rate", 0.05)),
        subsample=float(parameters.get("subsample", 0.8)),
        colsample_bytree=float(parameters.get("colsample_bytree", 0.8)),
        objective="multi:softprob",
        random_state=seed,
        n_jobs=-1,
    )


def verify_external_baseline_lock(lock_path: str | Path, model_id: str) -> dict:
    with Path(lock_path).open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    entry = payload["entries"][model_id]
    missing = [field for field in ("source_url", "revision", "license") if not entry.get(field)]
    if entry.get("status") != "verified" or missing:
        raise RuntimeError(
            f"{model_id} is not locked to a verified immutable source; missing: {missing}"
        )
    revision = str(entry["revision"])
    if revision in {"main", "master", "latest", "HEAD"} or len(revision) < 7:
        raise RuntimeError(f"{model_id} revision is mutable or incomplete")
    return entry


def fit_predict_probabilities(estimator, x_train: np.ndarray, y_train: np.ndarray, x_valid: np.ndarray):
    estimator.fit(x_train, y_train)
    return estimator.predict_proba(x_valid)

