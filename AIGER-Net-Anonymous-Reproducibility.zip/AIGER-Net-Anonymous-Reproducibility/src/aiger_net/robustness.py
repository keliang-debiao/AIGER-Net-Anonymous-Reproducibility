from __future__ import annotations

import io
import math

import numpy as np
from PIL import Image, ImageEnhance, ImageFilter


def jpeg_compress(image: Image.Image, quality: int) -> Image.Image:
    buffer = io.BytesIO()
    image.convert("RGB").save(buffer, format="JPEG", quality=int(quality))
    buffer.seek(0)
    return Image.open(buffer).convert("RGB")


def gaussian_blur(image: Image.Image, sigma: float) -> Image.Image:
    return image.filter(ImageFilter.GaussianBlur(radius=float(sigma)))


def color_perturb(image: Image.Image, severity: float, rng: np.random.Generator) -> Image.Image:
    low, high = 1.0 - severity, 1.0 + severity
    value = ImageEnhance.Brightness(image).enhance(float(rng.uniform(low, high)))
    value = ImageEnhance.Contrast(value).enhance(float(rng.uniform(low, high)))
    value = ImageEnhance.Color(value).enhance(float(rng.uniform(low, high)))
    hsv = np.asarray(value.convert("HSV"), dtype=np.uint8).copy()
    hue_shift = round(float(rng.uniform(-severity / 2, severity / 2)) * 255)
    hsv[..., 0] = (hsv[..., 0].astype(np.int16) + hue_shift) % 256
    return Image.fromarray(hsv, mode="HSV").convert("RGB")


def patch_mask(
    image: Image.Image,
    fraction: float,
    median_rgb: tuple[int, int, int],
    rng: np.random.Generator,
) -> Image.Image:
    resized = image.resize((448, 448)).convert("RGB")
    array = np.asarray(resized).copy()
    grid = 14
    patch = 32
    count = round(grid * grid * fraction)
    selected = rng.choice(grid * grid, size=count, replace=False)
    for index in selected:
        row, column = divmod(int(index), grid)
        array[row * patch : (row + 1) * patch, column * patch : (column + 1) * patch] = median_rgb
    return Image.fromarray(array)


def image_seed(work_id: str, root_seed: int) -> int:
    value = root_seed
    for byte in work_id.encode("utf-8"):
        value = (value * 1103515245 + byte + 12345) % (2**32)
    return value


def shifted_prior_weights(targets: np.ndarray, classes: int, gamma: float) -> np.ndarray:
    counts = np.bincount(np.asarray(targets, dtype=int), minlength=classes).astype(float)
    prior = counts / counts.sum()
    shifted = prior**gamma
    shifted /= shifted.sum()
    return shifted[np.asarray(targets, dtype=int)] / np.clip(prior[np.asarray(targets, dtype=int)], 1.0e-12, None)

