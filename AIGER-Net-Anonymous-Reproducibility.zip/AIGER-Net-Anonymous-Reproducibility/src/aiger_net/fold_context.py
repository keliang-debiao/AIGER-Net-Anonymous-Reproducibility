from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
import torch

from .features import FeatureStore


@dataclass
class FoldArrays:
    work_ids: np.ndarray
    image_embeddings: torch.Tensor
    text_embeddings: torch.Tensor
    text_mask: torch.Tensor
    labels: torch.Tensor
    artist_index: torch.Tensor
    artist_ids: np.ndarray
    duplicate_components: np.ndarray
    prompt_embeddings: torch.Tensor


def align_features(frame: pd.DataFrame, store: FeatureStore, device: torch.device) -> FoldArrays:
    lookup = {work_id: index for index, work_id in enumerate(store.work_ids.astype(str))}
    indices = np.array([lookup[str(work_id)] for work_id in frame["work_id"]], dtype=int)
    artists = frame["artist_id"].astype(str).to_numpy()
    unique_artists = {artist: index for index, artist in enumerate(sorted(set(artists)))}
    return FoldArrays(
        work_ids=frame["work_id"].astype(str).to_numpy(),
        image_embeddings=torch.from_numpy(store.image_embeddings[indices]).to(device),
        text_embeddings=torch.from_numpy(store.text_embeddings[indices]).to(device),
        text_mask=torch.from_numpy(store.text_mask[indices]).to(device),
        labels=torch.from_numpy(frame["style_id"].to_numpy(dtype=np.int64)).to(device),
        artist_index=torch.tensor([unique_artists[item] for item in artists], device=device),
        artist_ids=artists,
        duplicate_components=frame["duplicate_component"].astype(str).to_numpy(),
        prompt_embeddings=torch.from_numpy(store.prompt_embeddings).to(device),
    )


class FoldContext:
    def __init__(self, arrays: FoldArrays, num_classes: int, prototype_nodes: int, neighbors: int):
        self.arrays = arrays
        self.num_classes = num_classes
        self.prototype_nodes = prototype_nodes
        self.neighbors = neighbors
        self.image_projected: torch.Tensor | None = None
        self.text_projected: torch.Tensor | None = None
        self.style_code: torch.Tensor | None = None
        self.visual_prototypes: torch.Tensor | None = None
        self.textual_prototypes: torch.Tensor | None = None
        self.fused_prototypes: torch.Tensor | None = None

    @torch.no_grad()
    def refresh(self, model, chunk_size: int = 2048) -> None:
        model.eval()
        images, texts, codes = [], [], []
        for start in range(0, len(self.arrays.labels), chunk_size):
            stop = start + chunk_size
            image, text = model.project_inputs(
                self.arrays.image_embeddings[start:stop],
                self.arrays.text_embeddings[start:stop],
                self.arrays.text_mask[start:stop],
            )
            images.append(image)
            texts.append(text)
            codes.append(model.casd.encode(image, text, self.arrays.text_mask[start:stop]))
        self.image_projected = torch.cat(images)
        self.text_projected = torch.cat(texts)
        self.style_code = torch.cat(codes)
        visual = []
        for class_id in range(self.num_classes):
            selected = self.arrays.labels.eq(class_id)
            if not selected.any():
                raise RuntimeError(f"training fold has no class {class_id}")
            visual.append(self.image_projected[selected].mean(dim=0))
        self.visual_prototypes = torch.nn.functional.normalize(torch.stack(visual), dim=-1)
        self.textual_prototypes = torch.nn.functional.normalize(
            model.text_projection(self.arrays.prompt_embeddings), dim=-1
        )
        self.fused_prototypes = model.prototype_gate(
            self.visual_prototypes, self.textual_prototypes
        )

    def _eligible_neighbors(self, index: int) -> torch.Tensor:
        if self.style_code is None:
            raise RuntimeError("fold context has not been refreshed")
        if self.neighbors == 0:
            return torch.empty(0, dtype=torch.long, device=self.style_code.device)
        similarities = self.style_code @ self.style_code[index]
        eligible = np.ones(len(similarities), dtype=bool)
        eligible[index] = False
        eligible &= self.arrays.artist_ids != self.arrays.artist_ids[index]
        eligible &= self.arrays.duplicate_components != self.arrays.duplicate_components[index]
        candidate = torch.from_numpy(np.flatnonzero(eligible)).to(similarities.device)
        if len(candidate) < self.neighbors:
            raise RuntimeError("insufficient artist-excluded retrieval candidates")
        values = similarities[candidate]
        return candidate[torch.topk(values, k=self.neighbors).indices]

    def prepare(self, indices: torch.Tensor) -> dict[str, torch.Tensor]:
        if any(
            item is None
            for item in (
                self.image_projected,
                self.text_projected,
                self.style_code,
                self.visual_prototypes,
                self.textual_prototypes,
                self.fused_prototypes,
            )
        ):
            raise RuntimeError("fold context has not been refreshed")
        nearest = torch.argmax(self.style_code[indices] @ self.fused_prototypes.T, dim=-1)
        local_nodes = []
        relations = []
        masks = []
        neighbor_embeddings = []
        neighbor_label_prototypes = []
        for index in indices.tolist():
            prototype_scores = self.style_code[index] @ self.fused_prototypes.T
            prototype_index = torch.topk(
                prototype_scores, k=min(self.prototype_nodes, self.num_classes)
            ).indices
            neighbor_index = self._eligible_neighbors(index)
            nodes = torch.cat(
                [
                    self.style_code[index : index + 1],
                    self.fused_prototypes[prototype_index],
                    self.style_code[neighbor_index],
                ],
                dim=0,
            )
            relation = torch.cat(
                [
                    torch.zeros(1, dtype=torch.long, device=nodes.device),
                    torch.zeros(len(prototype_index), dtype=torch.long, device=nodes.device),
                    torch.ones(len(neighbor_index), dtype=torch.long, device=nodes.device),
                ]
            )
            local_nodes.append(nodes)
            relations.append(relation)
            masks.append(torch.ones(len(nodes), dtype=torch.bool, device=nodes.device))
            neighbor_embeddings.append(self.style_code[neighbor_index])
            neighbor_label_prototypes.append(self.fused_prototypes[self.arrays.labels[neighbor_index]])
        return {
            "image_embedding": self.arrays.image_embeddings[indices],
            "text_embedding": self.arrays.text_embeddings[indices],
            "text_mask": self.arrays.text_mask[indices],
            "visual_prototypes": self.visual_prototypes,
            "textual_prototypes": self.textual_prototypes,
            "nearest_prototype_index": nearest,
            "local_nodes": torch.stack(local_nodes),
            "relation_ids": torch.stack(relations)[0],
            "node_mask": torch.stack(masks),
            "neighbor_embeddings": torch.stack(neighbor_embeddings),
            "neighbor_label_prototypes": torch.stack(neighbor_label_prototypes),
            "style_id": self.arrays.labels[indices],
            "artist_index": self.arrays.artist_index[indices],
            "target_prototype": self.fused_prototypes[self.arrays.labels[indices]],
        }

    def _query_neighbors(
        self,
        query_code: torch.Tensor,
        query_artist: str,
        query_duplicate: str,
    ) -> torch.Tensor:
        if self.neighbors == 0:
            return torch.empty(0, dtype=torch.long, device=self.style_code.device)
        similarities = self.style_code @ query_code
        eligible = np.ones(len(similarities), dtype=bool)
        eligible &= self.arrays.artist_ids != query_artist
        eligible &= self.arrays.duplicate_components != query_duplicate
        candidate = torch.from_numpy(np.flatnonzero(eligible)).to(similarities.device)
        if len(candidate) < self.neighbors:
            raise RuntimeError("insufficient eligible training-memory candidates")
        return candidate[torch.topk(similarities[candidate], k=self.neighbors).indices]

    @torch.no_grad()
    def prepare_queries(self, model, query: FoldArrays, indices: torch.Tensor) -> dict[str, torch.Tensor]:
        if self.fused_prototypes is None or self.style_code is None:
            raise RuntimeError("fold context has not been refreshed")
        image, text = model.project_inputs(
            query.image_embeddings[indices],
            query.text_embeddings[indices],
            query.text_mask[indices],
        )
        query_codes = model.casd.encode(image, text, query.text_mask[indices])
        nearest = torch.argmax(query_codes @ self.fused_prototypes.T, dim=-1)
        local_nodes = []
        relations = []
        masks = []
        neighbor_embeddings = []
        neighbor_label_prototypes = []
        for local_position, query_index in enumerate(indices.tolist()):
            code = query_codes[local_position]
            prototype_index = torch.topk(
                code @ self.fused_prototypes.T,
                k=min(self.prototype_nodes, self.num_classes),
            ).indices
            neighbor_index = self._query_neighbors(
                code,
                str(query.artist_ids[query_index]),
                str(query.duplicate_components[query_index]),
            )
            nodes = torch.cat(
                [
                    code.unsqueeze(0),
                    self.fused_prototypes[prototype_index],
                    self.style_code[neighbor_index],
                ],
                dim=0,
            )
            relation = torch.cat(
                [
                    torch.zeros(1, dtype=torch.long, device=nodes.device),
                    torch.zeros(len(prototype_index), dtype=torch.long, device=nodes.device),
                    torch.ones(len(neighbor_index), dtype=torch.long, device=nodes.device),
                ]
            )
            local_nodes.append(nodes)
            relations.append(relation)
            masks.append(torch.ones(len(nodes), dtype=torch.bool, device=nodes.device))
            neighbor_embeddings.append(self.style_code[neighbor_index])
            neighbor_label_prototypes.append(self.fused_prototypes[self.arrays.labels[neighbor_index]])
        return {
            "image_embedding": query.image_embeddings[indices],
            "text_embedding": query.text_embeddings[indices],
            "text_mask": query.text_mask[indices],
            "visual_prototypes": self.visual_prototypes,
            "textual_prototypes": self.textual_prototypes,
            "nearest_prototype_index": nearest,
            "local_nodes": torch.stack(local_nodes),
            "relation_ids": torch.stack(relations)[0],
            "node_mask": torch.stack(masks),
            "neighbor_embeddings": torch.stack(neighbor_embeddings),
            "neighbor_label_prototypes": torch.stack(neighbor_label_prototypes),
            "style_id": query.labels[indices],
        }

