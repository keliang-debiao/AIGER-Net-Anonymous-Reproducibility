from __future__ import annotations

import os
import random
from dataclasses import dataclass

import numpy as np


def seed_everything(seed: int, deterministic: bool = True) -> None:
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    try:
        import torch

        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        if deterministic:
            torch.use_deterministic_algorithms(True, warn_only=True)
            torch.backends.cudnn.benchmark = False
    except ImportError:
        return


@dataclass(frozen=True)
class SeedStream:
    root: int

    def derive(self, namespace: str) -> int:
        value = self.root
        for char in namespace.encode("utf-8"):
            value = (value * 1664525 + char + 1013904223) % (2**32)
        return value

