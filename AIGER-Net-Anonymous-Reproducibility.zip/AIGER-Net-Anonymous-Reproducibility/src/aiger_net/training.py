from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

import torch
from torch import nn

from .losses import complete_loss


@dataclass
class EpochResult:
    loss: float
    batches: int


class Trainer:
    def __init__(self, model: nn.Module, config: dict, device: torch.device):
        self.model = model.to(device)
        self.config = config
        self.device = device
        optimization = config["optimization"]
        self.optimizer = torch.optim.AdamW(
            [parameter for parameter in model.parameters() if parameter.requires_grad],
            lr=float(optimization["learning_rate_new"]),
            weight_decay=float(optimization["weight_decay"]),
        )
        self.scaler = torch.cuda.amp.GradScaler(
            enabled=bool(optimization["mixed_precision"]) and device.type == "cuda"
        )
        self.accumulation = int(optimization["gradient_accumulation_steps"])
        self.clip = float(optimization["gradient_clip_norm"])

    def _grl_scale(self, epoch: int) -> float:
        maximum = int(self.config["optimization"]["max_epochs"])
        warmup = max(1, round(maximum * float(self.config["loss"]["artist_grl_warmup_fraction"])))
        return min(1.0, epoch / warmup)

    def _model_inputs(self, batch: dict, epoch: int) -> dict:
        keys = [
            "image_embedding",
            "text_embedding",
            "text_mask",
            "visual_prototypes",
            "textual_prototypes",
            "nearest_prototype_index",
            "local_nodes",
            "relation_ids",
            "node_mask",
            "neighbor_embeddings",
            "neighbor_label_prototypes",
        ]
        return {
            **{key: batch[key].to(self.device) for key in keys},
            "grl_scale": self._grl_scale(epoch),
        }

    def train_epoch(self, loader, epoch: int) -> EpochResult:
        self.model.train()
        self.optimizer.zero_grad(set_to_none=True)
        running = 0.0
        batches = 0
        amp_enabled = self.scaler.is_enabled()
        for step, batch in enumerate(loader):
            with torch.autocast(device_type=self.device.type, enabled=amp_enabled):
                output = self.model(**self._model_inputs(batch, epoch))
                image, text = self.model.project_inputs(
                    batch["image_embedding"].to(self.device),
                    batch["text_embedding"].to(self.device),
                    batch["text_mask"].to(self.device),
                )
                loss, _ = complete_loss(
                    self.model,
                    output,
                    batch["style_id"].to(self.device),
                    batch["artist_index"].to(self.device),
                    image,
                    text,
                    batch["text_mask"].to(self.device),
                    batch["target_prototype"].to(self.device),
                    self.config,
                    epoch,
                )
                loss = loss / self.accumulation
            self.scaler.scale(loss).backward()
            if (step + 1) % self.accumulation == 0:
                self.scaler.unscale_(self.optimizer)
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.clip)
                self.scaler.step(self.optimizer)
                self.scaler.update()
                self.optimizer.zero_grad(set_to_none=True)
            running += float(loss.detach()) * self.accumulation
            batches += 1
        return EpochResult(loss=running / max(1, batches), batches=batches)

    @torch.no_grad()
    def predict(self, loader) -> dict[str, torch.Tensor]:
        self.model.eval()
        collected: dict[str, list[torch.Tensor]] = {
            "probabilities": [],
            "uncertainty": [],
            "targets": [],
            "artist_index": [],
        }
        for batch in loader:
            output = self.model(**self._model_inputs(batch, epoch=10**6))
            collected["probabilities"].append(output.probabilities.cpu())
            collected["uncertainty"].append(output.uncertainty.cpu())
            collected["targets"].append(batch["style_id"].cpu())
            collected["artist_index"].append(batch["artist_index"].cpu())
        return {key: torch.cat(values) for key, values in collected.items()}


def cosine_schedule(optimizer, warmup_epochs: int, total_epochs: int):
    def multiplier(epoch: int) -> float:
        if epoch < warmup_epochs:
            return float(epoch + 1) / max(1, warmup_epochs)
        progress = (epoch - warmup_epochs) / max(1, total_epochs - warmup_epochs)
        return 0.5 * (1.0 + math.cos(math.pi * progress))

    return torch.optim.lr_scheduler.LambdaLR(optimizer, multiplier)


def save_checkpoint(path: str | Path, model: nn.Module, optimizer, epoch: int, config: dict) -> None:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    torch.save(
        {
            "model": model.state_dict(),
            "optimizer": optimizer.state_dict(),
            "epoch": epoch,
            "config": config,
        },
        destination,
    )

