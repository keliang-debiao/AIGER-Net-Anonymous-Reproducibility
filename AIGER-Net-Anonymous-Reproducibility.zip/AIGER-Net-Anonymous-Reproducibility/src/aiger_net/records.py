from __future__ import annotations

import platform
import sys
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .io import sha256_file, sha256_json, source_revision, write_json


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class RunRecord:
    run_id: str
    stage: str
    seed: int
    command: str
    config: dict[str, Any]
    manifest_path: str
    outer_fold: int | None = None
    record_status: str = "empirical"
    metrics: dict[str, Any] = field(default_factory=dict)
    artifacts: dict[str, str] = field(default_factory=dict)
    schema_version: int = 1
    source_revision: str = field(default_factory=source_revision)
    started_at: str = field(default_factory=utc_now)
    ended_at: str = ""
    checkpoint_sha256: str | None = None
    predictions_sha256: str | None = None

    def finish(self) -> None:
        self.ended_at = utc_now()

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["config_sha256"] = sha256_json(self.config)
        manifest = Path(self.manifest_path)
        payload["manifest_sha256"] = sha256_file(manifest) if manifest.exists() else "0" * 64
        payload["environment"] = {
            "python": sys.version.split()[0],
            "platform": platform.platform(),
        }
        payload.pop("config")
        payload.pop("manifest_path")
        return payload

    def save(self, path: str | Path, force: bool = False) -> Path:
        if self.record_status not in {"empirical", "reference-only"}:
            raise ValueError("invalid record status")
        if not self.ended_at:
            self.finish()
        return write_json(path, self.to_dict(), force=force)

