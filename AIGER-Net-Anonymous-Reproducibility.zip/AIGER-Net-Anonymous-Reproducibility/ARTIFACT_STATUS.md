# Artifact Status

This package contains an executable research pipeline and non-empirical target-format records.

The records under `records/reference_only/` are present only to validate parsers, tables, and expected metric fields before computational reproduction. They are not training logs, do not establish that a run was completed, and must not be submitted as empirical provenance. The package enforces this distinction through the `record_status` field and the reporting guard in `src/aiger_net/reporting.py`.

Valid reproduction evidence must be created by the supplied commands under `records/empirical/` and must contain:

- `record_status: empirical`;
- a complete command line;
- a configuration SHA-256 digest;
- a data-manifest SHA-256 digest;
- the source revision;
- start and end timestamps;
- the random seed and outer-fold identifier;
- checkpoint and prediction-file digests;
- measured metrics computed from saved predictions.

Reference-only values must be replaced by records from completed runs before the manuscript is represented as empirically reproduced.

The package intentionally does not fabricate immutable revisions or interfaces for third-party repositories. The art-specific adapters remain locked until the exact public sources used for reproduction are recorded in `third_party/LOCK.json`. Feature-token and image-backbone baselines retain their fixed search domains and fold contract but require execution in the locked GPU environment.

