from __future__ import annotations

import numpy as np
import pandas as pd

from _common import config_and_root, parser, print_json, write_parquet
from aiger_net.data.audit import duplicate_components, hamming_hex
from aiger_net.data.folds import assign_outer_folds
from aiger_net.features import FeatureStore


def attach_embeddings(frame: pd.DataFrame, store: FeatureStore) -> pd.DataFrame:
    lookup = {str(work_id): index for index, work_id in enumerate(store.work_ids)}
    output = frame.copy()
    output["embedding"] = [store.image_embeddings[lookup[str(work_id)]] for work_id in output["work_id"]]
    return output


def cross_dataset_matches(
    development: pd.DataFrame,
    external: pd.DataFrame,
    threshold: int,
    cosine_threshold: float,
) -> np.ndarray:
    development_sha = set(development["sha256"].astype(str))
    exact = external["sha256"].astype(str).isin(development_sha).to_numpy()
    buckets: dict[str, list[int]] = {}
    for index, value in enumerate(development["phash64"].astype(str)):
        for offset in range(0, 16, 4):
            buckets.setdefault(f"{offset}:{value[offset:offset + 4]}", []).append(index)
    matches = exact.copy()
    development_hashes = development["phash64"].astype(str).to_numpy()
    development_embeddings = np.stack(development["embedding"].to_numpy())
    for external_index, row in enumerate(external.itertuples(index=False)):
        if matches[external_index]:
            continue
        value = str(row.phash64)
        candidates = set()
        for offset in range(0, 16, 4):
            candidates.update(buckets.get(f"{offset}:{value[offset:offset + 4]}", []))
        query = np.asarray(row.embedding, dtype=float)
        query /= max(np.linalg.norm(query), 1.0e-8)
        for candidate in candidates:
            if hamming_hex(value, development_hashes[candidate]) > threshold:
                continue
            reference = development_embeddings[candidate]
            reference = reference / max(np.linalg.norm(reference), 1.0e-8)
            if float(reference @ query) >= cosine_threshold:
                matches[external_index] = True
                break
    return matches


def main() -> None:
    args = parser("Confirm duplicate components and create artist-grouped folds").parse_args()
    config, root = config_and_root(args.config)
    data = config["data"]
    development = pd.read_parquet(root / data["development_manifest"])
    external = pd.read_parquet(root / data["external_manifest"])
    development_store = FeatureStore.load(root / data["development_features"])
    external_store = FeatureStore.load(root / data["external_features"])
    development = attach_embeddings(development, development_store)
    external = attach_embeddings(external, external_store)
    development["duplicate_component"] = duplicate_components(
        development,
        int(data["phash_threshold"]),
        float(data["duplicate_embedding_cosine"]),
    )
    external["duplicate_component"] = duplicate_components(
        external,
        int(data["phash_threshold"]),
        float(data["duplicate_embedding_cosine"]),
    )
    external["cross_dataset_match"] = cross_dataset_matches(
        development,
        external,
        int(data["phash_threshold"]),
        float(data["duplicate_embedding_cosine"]),
    ).astype(int)
    external["eligible_primary"] = (
        external["eligible_primary"].eq(1) & external["cross_dataset_match"].eq(0)
    ).astype(int)
    external["eligible_harmonized"] = (
        external["eligible_harmonized"].eq(1) & external["cross_dataset_match"].eq(0)
    ).astype(int)
    eligible = development.loc[development["eligible_primary"].eq(1)].drop(columns="embedding")
    folded = assign_outer_folds(
        eligible,
        int(config["split"]["outer_folds"]),
        int(config["split"]["seed"]),
    )
    development = development.drop(columns="embedding").merge(
        folded[["work_id", "outer_fold"]], on="work_id", how="left"
    )
    external = external.drop(columns="embedding")
    write_parquet(development, root / data["fold_manifest"], args.force)
    write_parquet(external, root / data["external_manifest"], True)
    audit = (
        folded.groupby(["style_id", "style_name"])
        .agg(
            retained_paintings=("work_id", "size"),
            distinct_artists=("artist_id", "nunique"),
            text_available_rate=("text_available", "mean"),
        )
        .reset_index()
    )
    audit.to_csv(root / "data/processed/class_audit_manifest.csv", index=False)
    print_json(
        {
            "development_eligible": len(folded),
            "fold_sizes": folded["outer_fold"].value_counts().sort_index().to_dict(),
            "external_eligible": int(external["eligible_primary"].sum()),
            "external_cross_dataset_matches": int(external["cross_dataset_match"].sum()),
        }
    )


if __name__ == "__main__":
    main()

