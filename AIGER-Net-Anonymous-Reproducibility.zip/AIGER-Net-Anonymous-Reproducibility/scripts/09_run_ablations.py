from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

import yaml

from _common import ROOT, config_and_root, print_json
from aiger_net.config import apply_dotted_overrides, load_yaml


def execute(command: list[str], root: Path) -> None:
    subprocess.run(command, cwd=root, check=True)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run component-removal studies")
    parser.add_argument("--config", default=str(ROOT / "configs/base.yaml"))
    parser.add_argument("--id", action="append")
    parser.add_argument("--all", action="store_true")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    base, root = config_and_root(args.config)
    definitions = load_yaml(root / "configs/ablations.yaml")["ablations"]
    selected = definitions if args.all else [item for item in definitions if item["id"] in (args.id or [])]
    if not selected:
        raise SystemExit("pass --all or at least one --id")
    completed = []
    for item in selected:
        run_id = str(item["id"])
        resolved = apply_dotted_overrides(base, item["overrides"])
        artifact_root = root / "runs" / run_id
        if run_id == "simplified_backbone":
            resolved["data"]["development_features"] = (
                f"runs/{run_id}/features/wikiart_features.npz"
            )
            resolved["data"]["external_features"] = (
                f"runs/{run_id}/features/best_artworks_features.npz"
            )
        config_path = artifact_root / "resolved_config.yaml"
        config_path.parent.mkdir(parents=True, exist_ok=True)
        if config_path.exists() and not args.force:
            raise FileExistsError(f"refusing to overwrite {config_path}; pass --force")
        with config_path.open("w", encoding="utf-8") as handle:
            yaml.safe_dump(resolved, handle, sort_keys=False)
        force = ["--force"] if args.force else []
        if run_id == "simplified_backbone":
            execute(
                [sys.executable, "scripts/03_extract_embeddings.py", "--config", str(config_path), "--dataset", "both", *force],
                root,
            )
        execute(
            [sys.executable, "scripts/05_train.py", "--config", str(config_path), "--all-folds", "--artifact-root", str(artifact_root), *force],
            root,
        )
        execute(
            [sys.executable, "scripts/06_evaluate_internal.py", "--config", str(config_path), "--artifact-root", str(artifact_root), *force],
            root,
        )
        execute(
            [sys.executable, "scripts/07_evaluate_external.py", "--config", str(config_path), "--artifact-root", str(artifact_root), *force],
            root,
        )
        completed.append(run_id)
    print_json({"completed": completed, "record_status": "empirical"})


if __name__ == "__main__":
    main()
