from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from _common import ROOT, print_json
from aiger_net.statistics import holm_adjust, matched_fold_contrast


def main() -> None:
    parser = argparse.ArgumentParser(description="Compute matched-fold contrasts and Holm adjustments")
    parser.add_argument("--input", required=True)
    parser.add_argument("--reference", default="aiger_net")
    parser.add_argument("--metric", default="macro_f1")
    parser.add_argument("--output", default=str(ROOT / "records/empirical/statistics/matched_contrasts.csv"))
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    frame = pd.read_csv(args.input)
    required = {"model_id", "outer_fold", args.metric}
    missing = sorted(required - set(frame.columns))
    if missing:
        raise KeyError(f"input lacks fields: {missing}")
    pivot = frame.pivot(index="outer_fold", columns="model_id", values=args.metric).sort_index()
    if args.reference not in pivot:
        raise KeyError(f"reference model is absent: {args.reference}")
    rows = []
    for model_id in sorted(column for column in pivot.columns if column != args.reference):
        paired = pivot[[args.reference, model_id]].dropna()
        if len(paired) != 5:
            raise ValueError(f"{model_id} does not have five matched folds")
        mean, interval, raw_p = matched_fold_contrast(
            paired[args.reference].to_numpy(), paired[model_id].to_numpy()
        )
        rows.append(
            {
                "reference_model": args.reference,
                "comparator": model_id,
                "metric": args.metric,
                "mean_difference": mean,
                "ci_lower": interval[0],
                "ci_upper": interval[1],
                "raw_p": raw_p,
            }
        )
    adjusted = holm_adjust([row["raw_p"] for row in rows])
    for row, value in zip(rows, adjusted, strict=True):
        row["holm_p"] = value
        row["record_status"] = "empirical"
    destination = Path(args.output)
    if not destination.is_absolute():
        destination = ROOT / destination
    if destination.exists() and not args.force:
        raise FileExistsError(f"refusing to overwrite {destination}; pass --force")
    destination.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(destination, index=False)
    print_json({"contrasts": len(rows), "output": str(destination)})


if __name__ == "__main__":
    main()
