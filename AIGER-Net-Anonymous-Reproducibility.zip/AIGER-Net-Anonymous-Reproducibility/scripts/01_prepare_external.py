from __future__ import annotations

from pathlib import Path

from _common import config_and_root, parser, print_json, write_parquet
from aiger_net.data.audit import summarize_manifest
from aiger_net.data.builders import build_external_manifest


def main() -> None:
    args = parser("Build the Best Artworks external manifest").parse_args()
    config, root = config_and_root(args.config)
    data = config["data"]
    manifest = build_external_manifest(
        root / data["external_root"],
        root / data["label_map"],
        int(data["phash_threshold"]),
        float(data["duplicate_embedding_cosine"]),
    )
    destination = root / data["external_manifest"]
    write_parquet(manifest, destination, args.force)
    print_json({"output": str(destination), **summarize_manifest(manifest).__dict__})


if __name__ == "__main__":
    main()

