from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from _common import ROOT, config_and_root, print_json
from aiger_net.metrics import classification_metrics
from aiger_net.statistics import artist_cluster_bootstrap


def main() -> None:
    parser = argparse.ArgumentParser(description="Score a completed robustness prediction bundle")
    parser.add_argument("--config", default=str(ROOT / "configs/base.yaml"))
    parser.add_argument("--condition", required=True)
    parser.add_argument("--probabilities", required=True)
    parser.add_argument("--metadata", required=True)
    parser.add_argument("--output", default="records/empirical/robustness")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    config, root = config_and_root(args.config)
    probabilities = np.load(args.probabilities)
    metadata = pd.read_parquet(args.metadata)
    if len(metadata) != len(probabilities):
        raise ValueError("metadata and probability rows differ")
    labels = metadata["style_id"].to_numpy(dtype=int)
    metrics = classification_metrics(probabilities, labels, int(config["calibration"]["ece_bins"]))
    point, lower, upper = artist_cluster_bootstrap(
        metadata["artist_id"].astype(str).to_numpy(),
        lambda index: classification_metrics(
            probabilities[index], labels[index], int(config["calibration"]["ece_bins"])
        )["macro_f1"],
        int(config["statistics"]["bootstrap_replicates"]),
        int(config["statistics"]["bootstrap_seed"]),
    )
    row = {
        "condition": args.condition,
        "eligible_paintings": len(metadata),
        **metrics,
        "macro_f1_cluster_point": point,
        "macro_f1_cluster_ci_lower": lower,
        "macro_f1_cluster_ci_upper": upper,
        "record_status": "empirical",
    }
    destination = root / args.output / f"{args.condition}.csv"
    if destination.exists() and not args.force:
        raise FileExistsError(f"refusing to overwrite {destination}; pass --force")
    destination.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame([row]).to_csv(destination, index=False)
    print_json(row)


if __name__ == "__main__":
    main()
