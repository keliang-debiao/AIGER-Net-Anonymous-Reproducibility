from __future__ import annotations

import argparse
import copy
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from sklearn.metrics import f1_score

from _common import ROOT, config_and_root, print_json
from aiger_net.data.folds import calibration_artists, fold_view
from aiger_net.features import FeatureStore
from aiger_net.fold_context import FoldContext, align_features
from aiger_net.io import sha256_file
from aiger_net.losses import complete_loss
from aiger_net.models import AIGERNet
from aiger_net.records import RunRecord
from aiger_net.reproducibility import seed_everything


def batches(labels: torch.Tensor, batch_size: int, generator: torch.Generator):
    labels_cpu = labels.detach().cpu()
    counts = torch.bincount(labels_cpu).float().clamp_min(1.0)
    weights = counts.reciprocal()[labels_cpu]
    permutation = torch.multinomial(
        weights,
        num_samples=len(labels_cpu),
        replacement=True,
        generator=generator,
    )
    for start in range(0, len(labels_cpu), batch_size):
        yield permutation[start : start + batch_size]


@torch.no_grad()
def predict_queries(model, memory, query_arrays, batch_size: int) -> tuple[np.ndarray, np.ndarray]:
    model.eval()
    values = []
    uncertainties = []
    for start in range(0, len(query_arrays.labels), batch_size):
        indices = torch.arange(
            start,
            min(start + batch_size, len(query_arrays.labels)),
            device=query_arrays.labels.device,
        )
        prepared = memory.prepare_queries(model, query_arrays, indices)
        model_inputs = {key: prepared[key] for key in (
            "image_embedding",
            "text_embedding",
            "text_mask",
            "visual_prototypes",
            "textual_prototypes",
            "nearest_prototype_index",
            "local_nodes",
            "relation_ids",
            "node_mask",
            "neighbor_embeddings",
            "neighbor_label_prototypes",
        )}
        output = model(**model_inputs, grl_scale=0.0)
        values.append(output.probabilities.cpu().numpy())
        uncertainties.append(output.uncertainty.cpu().numpy())
    return np.concatenate(values), np.concatenate(uncertainties)


def save_prediction_bundle(
    root: Path,
    name: str,
    frame: pd.DataFrame,
    probabilities: np.ndarray,
    uncertainty: np.ndarray,
) -> tuple[Path, Path, Path]:
    directory = root / "predictions"
    directory.mkdir(parents=True, exist_ok=True)
    metadata_path = directory / f"{name}.parquet"
    probability_path = directory / f"{name}.npy"
    uncertainty_path = directory / f"{name}_uncertainty.npy"
    frame.to_parquet(metadata_path, index=False)
    np.save(probability_path, probabilities)
    np.save(uncertainty_path, uncertainty)
    return metadata_path, probability_path, uncertainty_path


def train_fold(config: dict, root: Path, artifact_root: Path, fold: int, force: bool) -> dict:
    seed = int(config["split"]["seed"])
    seed_everything(seed + fold)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    manifest_path = root / config["data"]["fold_manifest"]
    frame = pd.read_parquet(manifest_path)
    frame = frame.loc[frame["eligible_primary"].eq(1)].copy()
    view = fold_view(
        frame,
        fold,
        float(config["split"]["calibration_artist_fraction"]),
        seed,
    )
    selection_artist_ids = calibration_artists(view.train, 1.0 / 3.0, seed + 1000 + fold)
    selection = view.train.loc[view.train["artist_id"].astype(str).isin(selection_artist_ids)].copy()
    fitting = view.train.loc[~view.train["artist_id"].astype(str).isin(selection_artist_ids)].copy()
    store = FeatureStore.load(root / config["data"]["development_features"])
    fit_arrays = align_features(fitting, store, device)
    selection_arrays = align_features(selection, store, device)
    calibration_arrays = align_features(view.calibration, store, device)
    validation_arrays = align_features(view.validation, store, device)
    model = AIGERNet(config, num_artists=int(fitting["artist_id"].nunique())).to(device)
    memory = FoldContext(
        fit_arrays,
        int(config["model"]["num_classes"]),
        int(config["model"]["prototype_nodes"]),
        int(config["model"]["retrieval_neighbors"]),
    )
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=float(config["optimization"]["learning_rate_new"]),
        weight_decay=float(config["optimization"]["weight_decay"]),
    )
    scaler = torch.cuda.amp.GradScaler(
        enabled=bool(config["optimization"]["mixed_precision"]) and device.type == "cuda"
    )
    batch_size = int(config["optimization"]["batch_size_per_device"])
    accumulation = int(config["optimization"]["gradient_accumulation_steps"])
    patience = int(config["optimization"]["early_stopping_patience"])
    maximum_epochs = int(config["optimization"]["max_epochs"])
    warmup_epochs = int(config["optimization"]["warmup_epochs"])
    scheduler = torch.optim.lr_scheduler.LambdaLR(
        optimizer,
        lr_lambda=lambda current: (
            (current + 1) / max(1, warmup_epochs)
            if current < warmup_epochs
            else 0.5
            * (
                1.0
                + np.cos(
                    np.pi
                    * (current - warmup_epochs)
                    / max(1, maximum_epochs - warmup_epochs)
                )
            )
        ),
    )
    best_score = -np.inf
    best_state = None
    best_epoch = 0
    stale = 0
    generator = torch.Generator().manual_seed(seed + fold)
    history = []
    for epoch in range(1, maximum_epochs + 1):
        memory.refresh(model)
        model.train()
        optimizer.zero_grad(set_to_none=True)
        losses = []
        warmup_fraction = float(config["loss"]["artist_grl_warmup_fraction"])
        grl_scale = min(1.0, epoch / max(1, round(maximum_epochs * warmup_fraction)))
        for step, indices in enumerate(batches(fit_arrays.labels, batch_size, generator)):
            indices = indices.to(device)
            prepared = memory.prepare(indices)
            model_inputs = {key: prepared[key] for key in (
                "image_embedding",
                "text_embedding",
                "text_mask",
                "visual_prototypes",
                "textual_prototypes",
                "nearest_prototype_index",
                "local_nodes",
                "relation_ids",
                "node_mask",
                "neighbor_embeddings",
                "neighbor_label_prototypes",
            )}
            with torch.autocast(device_type=device.type, enabled=scaler.is_enabled()):
                output = model(**model_inputs, grl_scale=grl_scale)
                image, text = model.project_inputs(
                    prepared["image_embedding"], prepared["text_embedding"], prepared["text_mask"]
                )
                loss, parts = complete_loss(
                    model,
                    output,
                    prepared["style_id"],
                    prepared["artist_index"],
                    image,
                    text,
                    prepared["text_mask"],
                    prepared["target_prototype"],
                    config,
                    epoch,
                )
                scaled_loss = loss / accumulation
            scaler.scale(scaled_loss).backward()
            if (step + 1) % accumulation == 0:
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), float(config["optimization"]["gradient_clip_norm"]))
                scaler.step(optimizer)
                scaler.update()
                optimizer.zero_grad(set_to_none=True)
            losses.append(parts["total"])
        if len(fit_arrays.labels) and (step + 1) % accumulation != 0:
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(
                model.parameters(),
                float(config["optimization"]["gradient_clip_norm"]),
            )
            scaler.step(optimizer)
            scaler.update()
            optimizer.zero_grad(set_to_none=True)
        scheduler.step()
        memory.refresh(model)
        selection_probabilities, _ = predict_queries(model, memory, selection_arrays, batch_size)
        selection_score = f1_score(
            selection_arrays.labels.cpu().numpy(),
            selection_probabilities.argmax(axis=1),
            average="macro",
        )
        history.append(
            {"epoch": epoch, "training_loss": float(np.mean(losses)), "selection_macro_f1": float(selection_score)}
        )
        if selection_score > best_score:
            best_score = float(selection_score)
            best_epoch = epoch
            best_state = copy.deepcopy(model.state_dict())
            stale = 0
        else:
            stale += 1
        if stale >= patience:
            break
    if best_state is None:
        raise RuntimeError("training did not produce a checkpoint")
    model.load_state_dict(best_state)
    memory.refresh(model)
    checkpoint = artifact_root / f"checkpoints/fold_{fold}/model.pt"
    checkpoint.parent.mkdir(parents=True, exist_ok=True)
    if checkpoint.exists() and not force:
        raise FileExistsError(f"refusing to overwrite {checkpoint}; pass --force")
    torch.save({"model": best_state, "config": config, "best_epoch": best_epoch}, checkpoint)
    calibration_probabilities, calibration_uncertainty = predict_queries(
        model, memory, calibration_arrays, batch_size
    )
    validation_probabilities, validation_uncertainty = predict_queries(
        model, memory, validation_arrays, batch_size
    )
    calibration_meta, calibration_values, calibration_uncertainty_path = save_prediction_bundle(
        artifact_root,
        f"fold_{fold}_calibration_raw",
        view.calibration,
        calibration_probabilities,
        calibration_uncertainty,
    )
    validation_meta, validation_values, validation_uncertainty_path = save_prediction_bundle(
        artifact_root,
        f"fold_{fold}_validation_raw",
        view.validation,
        validation_probabilities,
        validation_uncertainty,
    )
    record = RunRecord(
        run_id=f"seed_{seed}_fold_{fold}_training",
        stage="training",
        seed=seed,
        outer_fold=fold,
        command=" ".join(sys.argv),
        config=config,
        manifest_path=str(manifest_path),
        metrics={
            "best_epoch": best_epoch,
            "selection_macro_f1": best_score,
            "training_rows": len(fitting),
            "selection_rows": len(selection),
            "calibration_rows": len(view.calibration),
            "validation_rows": len(view.validation),
        },
        artifacts={
            "checkpoint": str(checkpoint),
            "calibration_metadata": str(calibration_meta),
            "calibration_probabilities": str(calibration_values),
            "calibration_uncertainty": str(calibration_uncertainty_path),
            "validation_metadata": str(validation_meta),
            "validation_probabilities": str(validation_values),
            "validation_uncertainty": str(validation_uncertainty_path),
        },
    )
    record.checkpoint_sha256 = sha256_file(checkpoint)
    record.predictions_sha256 = sha256_file(validation_values)
    record_path = artifact_root / f"records/empirical/training/seed_{seed}_fold_{fold}.json"
    record.save(record_path, force=force)
    history_path = artifact_root / f"records/empirical/training/seed_{seed}_fold_{fold}_epochs.csv"
    history_path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(history).to_csv(history_path, index=False)
    return record.to_dict()


def main() -> None:
    value = argparse.ArgumentParser(description="Train fold-specific AIGER-Net models")
    value.add_argument("--config", default=str(ROOT / "configs/base.yaml"))
    value.add_argument("--fold", type=int)
    value.add_argument("--all-folds", action="store_true")
    value.add_argument("--artifact-root", default=".")
    value.add_argument("--force", action="store_true")
    args = value.parse_args()
    config, root = config_and_root(args.config)
    if args.all_folds:
        folds = range(int(config["split"]["outer_folds"]))
    elif args.fold is not None:
        folds = [args.fold]
    else:
        raise SystemExit("pass --fold or --all-folds")
    artifact_root = (root / args.artifact_root).resolve()
    output = [train_fold(config, root, artifact_root, fold, args.force) for fold in folds]
    print_json({"completed_folds": [item["outer_fold"] for item in output]})


if __name__ == "__main__":
    main()

