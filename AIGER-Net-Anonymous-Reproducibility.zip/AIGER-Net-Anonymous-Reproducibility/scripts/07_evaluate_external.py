from __future__ import annotations

import argparse
import sys

import numpy as np
import pandas as pd
import torch

from _common import ROOT, config_and_root, print_json
from aiger_net.calibration import APSCalibrator, TemperatureScaler
from aiger_net.data.folds import calibration_artists, fold_view
from aiger_net.features import FeatureStore
from aiger_net.fold_context import FoldContext, align_features
from aiger_net.io import sha256_file
from aiger_net.metrics import classification_metrics, partial_label_metrics
from aiger_net.models import AIGERNet
from aiger_net.records import RunRecord


def movement_sets(frame: pd.DataFrame, label_map: pd.DataFrame) -> list[set[int]]:
    lookup = {row.normalized_label: int(row.style_id) for row in label_map.itertuples(index=False)}
    return [
        {lookup[token] for token in str(value).split("|") if token in lookup}
        for value in frame["movement_set"]
    ]


@torch.no_grad()
def predict(model, memory, query_arrays, batch_size: int) -> np.ndarray:
    model.eval()
    values = []
    for start in range(0, len(query_arrays.labels), batch_size):
        indices = torch.arange(start, min(start + batch_size, len(query_arrays.labels)), device=query_arrays.labels.device)
        prepared = memory.prepare_queries(model, query_arrays, indices)
        model_inputs = {key: prepared[key] for key in (
            "image_embedding", "text_embedding", "text_mask", "visual_prototypes",
            "textual_prototypes", "nearest_prototype_index", "local_nodes",
            "relation_ids", "node_mask", "neighbor_embeddings", "neighbor_label_prototypes",
        )}
        values.append(model(**model_inputs, grl_scale=0.0).probabilities.cpu().numpy())
    return np.concatenate(values)


def main() -> None:
    value = argparse.ArgumentParser(description="Run zero-tuning external evaluation")
    value.add_argument("--config", default=str(ROOT / "configs" / "base.yaml"))
    value.add_argument("--artifact-root", default=".")
    value.add_argument("--force", action="store_true")
    args = value.parse_args()
    config, root = config_and_root(args.config)
    artifact_root = (root / args.artifact_root).resolve()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    development = pd.read_parquet(root / config["data"]["fold_manifest"])
    development = development.loc[development["eligible_primary"].eq(1)].copy()
    external = pd.read_parquet(root / config["data"]["external_manifest"])
    external = external.loc[external["eligible_primary"].eq(1)].copy()
    label_map = pd.read_csv(root / config["data"]["label_map"])
    allowed = movement_sets(external, label_map)
    external["style_id"] = [min(values) for values in allowed]
    development_store = FeatureStore.load(root / config["data"]["development_features"])
    external_store = FeatureStore.load(root / config["data"]["external_features"])
    external_arrays = align_features(external, external_store, device)
    external_arrays.text_mask.zero_()
    fold_probabilities = []
    fold_quantiles = []
    seed = int(config["split"]["seed"])
    for fold in range(int(config["split"]["outer_folds"])):
        view = fold_view(
            development,
            fold,
            float(config["split"]["calibration_artist_fraction"]),
            seed,
        )
        selection_artists = calibration_artists(view.train, 1.0 / 3.0, seed + 1000 + fold)
        fitting = view.train.loc[~view.train["artist_id"].astype(str).isin(selection_artists)].copy()
        fitting_arrays = align_features(fitting, development_store, device)
        model = AIGERNet(config, num_artists=int(fitting["artist_id"].nunique())).to(device)
        checkpoint = torch.load(artifact_root / f"checkpoints/fold_{fold}/model.pt", map_location=device)
        model.load_state_dict(checkpoint["model"])
        memory = FoldContext(
            fitting_arrays,
            int(config["model"]["num_classes"]),
            int(config["model"]["prototype_nodes"]),
            int(config["model"]["retrieval_neighbors"]),
        )
        memory.refresh(model)
        raw = predict(model, memory, external_arrays, int(config["optimization"]["batch_size_per_device"]))
        calibration_frame = pd.read_parquet(artifact_root / f"predictions/fold_{fold}_calibration_raw.parquet")
        calibration_raw = np.load(artifact_root / f"predictions/fold_{fold}_calibration_raw.npy")
        scaler = TemperatureScaler().fit(calibration_raw, calibration_frame["style_id"].to_numpy(dtype=int))
        fold_probabilities.append(scaler.transform(raw))
        calibration_scaled = scaler.transform(calibration_raw)
        aps = APSCalibrator(
            float(config["calibration"]["aps_target_coverage"]), seed=seed + fold
        ).fit(
            calibration_scaled, calibration_frame["style_id"].to_numpy(dtype=int)
        )
        fold_quantiles.append(float(aps.quantile))
    probabilities = np.mean(fold_probabilities, axis=0)
    aps = APSCalibrator(
        float(config["calibration"]["aps_target_coverage"]), seed=seed + 1000
    )
    aps.quantile = float(np.mean(fold_quantiles))
    sets = aps.sets(probabilities)
    all_metrics = partial_label_metrics(
        probabilities,
        allowed,
        sets,
        int(config["calibration"]["ece_bins"]),
    )
    single_mask = np.array([len(values) == 1 for values in allowed])
    single_targets = np.array([next(iter(values)) for values in np.asarray(allowed, dtype=object)[single_mask]])
    single_metrics = classification_metrics(
        probabilities[single_mask],
        single_targets,
        int(config["calibration"]["ece_bins"]),
    )
    np.save(artifact_root / "predictions/external_calibrated.npy", probabilities)
    np.save(artifact_root / "predictions/external_sets.npy", sets)
    external.to_parquet(artifact_root / "predictions/external_metadata.parquet", index=False)
    metrics = {
        "all_eligible_n": int(len(external)),
        "single_tag_n": int(single_mask.sum()),
        **{f"all_{key}": value for key, value in all_metrics.items()},
        **{f"single_{key}": value for key, value in single_metrics.items()},
    }
    record = RunRecord(
        run_id=f"seed_{seed}_external",
        stage="external_evaluation",
        seed=seed,
        command=" ".join(sys.argv),
        config=config,
        manifest_path=str(root / config["data"]["external_manifest"]),
        metrics=metrics,
        artifacts={"probabilities": "predictions/external_calibrated.npy", "sets": "predictions/external_sets.npy"},
    )
    record.predictions_sha256 = sha256_file(artifact_root / "predictions/external_calibrated.npy")
    record.save(artifact_root / "records/empirical/evaluation/external.json", force=args.force)
    print_json(metrics)


if __name__ == "__main__":
    main()

