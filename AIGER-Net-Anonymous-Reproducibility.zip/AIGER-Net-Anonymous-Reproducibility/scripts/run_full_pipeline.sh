#!/usr/bin/env bash
set -euo pipefail

CONFIG_PATH="${1:-configs/base.yaml}"

python scripts/00_validate_environment.py
python scripts/01_prepare_external.py --config "$CONFIG_PATH"
python scripts/02_prepare_development.py --config "$CONFIG_PATH"
python scripts/03_extract_embeddings.py --config "$CONFIG_PATH" --dataset both
python scripts/04_finalize_audit_and_folds.py --config "$CONFIG_PATH"
python scripts/05_train.py --config "$CONFIG_PATH" --all-folds
python scripts/06_evaluate_internal.py --config "$CONFIG_PATH"
python scripts/07_evaluate_external.py --config "$CONFIG_PATH"

for MODEL_ID in logistic_regression random_forest xgboost two_layer_mlp qwen3_vl_head; do
  python scripts/08_run_baselines.py --config "$CONFIG_PATH" --model "$MODEL_ID"
done

python scripts/12_build_report_tables.py --records records/empirical --output reports/generated
