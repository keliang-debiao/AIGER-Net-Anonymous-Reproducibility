from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image

from _common import ROOT, config_and_root, print_json
from aiger_net.features import FeatureStore, OnlineFoundationEncoder


def encode_manifest(
    frame: pd.DataFrame,
    image_root: Path,
    encoder: OnlineFoundationEncoder,
    prompts: list[str],
    batch_size: int,
    text_supported: bool,
) -> FeatureStore:
    image_blocks = []
    text_blocks = []
    text_mask = frame["text_available"].to_numpy(dtype=np.float32)
    for start in range(0, len(frame), batch_size):
        batch = frame.iloc[start : start + batch_size]
        images = []
        for relative_path in batch["relative_path"]:
            with Image.open(image_root / str(relative_path)) as handle:
                images.append(handle.convert("RGB").copy())
        image_values = encoder.encode_images(images)
        image_blocks.append(image_values)
        if text_supported:
            texts = [text if text else "[missing text]" for text in batch["description_clean"].astype(str)]
            text_blocks.append(encoder.encode_texts(texts))
        else:
            text_blocks.append(np.zeros_like(image_values))
    if text_supported:
        prompt_embeddings = encoder.encode_texts(prompts)
    else:
        prompt_embeddings = np.zeros((len(prompts), image_blocks[0].shape[1]), dtype=np.float32)
        text_mask = np.zeros_like(text_mask)
    return FeatureStore(
        work_ids=frame["work_id"].astype(str).to_numpy(),
        image_embeddings=np.concatenate(image_blocks),
        text_embeddings=np.concatenate(text_blocks),
        text_mask=text_mask,
        prompt_embeddings=prompt_embeddings,
    )


def main() -> None:
    value = argparse.ArgumentParser(description="Extract frozen foundation embeddings")
    value.add_argument("--config", default=str(ROOT / "configs" / "base.yaml"))
    value.add_argument("--dataset", choices=["development", "external", "both"], default="both")
    value.add_argument("--batch-size", type=int, default=8)
    value.add_argument("--device", default="cuda")
    value.add_argument("--force", action="store_true")
    args = value.parse_args()
    config, root = config_and_root(args.config)
    encoder = OnlineFoundationEncoder(
        config["foundation"]["model_name"],
        args.device,
        bool(config["foundation"]["trust_remote_code"]),
    )
    class_map = pd.read_csv(root / config["data"]["label_map"]).sort_values("style_id")
    prompts = [f"a painting in the visual tradition of {name}" for name in class_map["development_label"]]
    completed = {}
    definitions = {
        "development": (
            root / config["data"]["development_manifest"],
            root / config["data"]["wikiart_root"],
            root / config["data"]["development_features"],
        ),
        "external": (
            root / config["data"]["external_manifest"],
            root / config["data"]["external_root"],
            root / config["data"]["external_features"],
        ),
    }
    selected = definitions if args.dataset == "both" else {args.dataset: definitions[args.dataset]}
    for name, (manifest_path, image_root, output_path) in selected.items():
        if output_path.exists() and not args.force:
            raise FileExistsError(f"refusing to overwrite {output_path}; pass --force")
        frame = pd.read_parquet(manifest_path)
        store = encode_manifest(
            frame,
            image_root,
            encoder,
            prompts,
            args.batch_size,
            bool(config["foundation"].get("text_supported", True)),
        )
        store.save(output_path)
        completed[name] = {"rows": len(frame), "output": str(output_path)}
    print_json(completed)


if __name__ == "__main__":
    main()

