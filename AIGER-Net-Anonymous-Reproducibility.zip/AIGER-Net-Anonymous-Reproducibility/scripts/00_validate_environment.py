from __future__ import annotations

import importlib
import platform
import sys

from _common import print_json


REQUIRED = {
    "numpy": "1.26",
    "pandas": "2.2",
    "scipy": "1.14",
    "sklearn": "1.5",
    "torch": "2.4",
    "torchvision": "0.19",
    "transformers": "4.48",
    "timm": "1.0",
    "xgboost": "2.1",
    "yaml": "6.0",
    "PIL": "11.0",
}


def main() -> None:
    packages = {}
    failures = []
    for module_name, prefix in REQUIRED.items():
        try:
            module = importlib.import_module(module_name)
            version = str(getattr(module, "__version__", "unknown"))
            packages[module_name] = version
            if version != "unknown" and not version.startswith(prefix):
                failures.append(f"{module_name}={version}, expected {prefix}.x")
        except ImportError:
            packages[module_name] = "missing"
            failures.append(f"{module_name} is missing")
    hardware = {"cuda_available": False, "gpu_count": 0, "gpus": []}
    try:
        import torch

        hardware["cuda_available"] = torch.cuda.is_available()
        hardware["gpu_count"] = torch.cuda.device_count()
        hardware["gpus"] = [torch.cuda.get_device_name(index) for index in range(torch.cuda.device_count())]
    except ImportError:
        pass
    payload = {
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "packages": packages,
        "hardware": hardware,
        "status": "pass" if not failures else "fail",
        "failures": failures,
    }
    print_json(payload)
    if failures:
        raise SystemExit(2)


if __name__ == "__main__":
    main()

