from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from aiger_net.config import load_yaml  # noqa: E402


def parser(description: str) -> argparse.ArgumentParser:
    value = argparse.ArgumentParser(description=description)
    value.add_argument("--config", default=str(ROOT / "configs" / "base.yaml"))
    value.add_argument("--force", action="store_true")
    return value


def config_and_root(path: str) -> tuple[dict, Path]:
    config = load_yaml(path)
    return config, ROOT


def write_parquet(frame: pd.DataFrame, path: str | Path, force: bool) -> Path:
    destination = Path(path)
    if destination.exists() and not force:
        raise FileExistsError(f"refusing to overwrite {destination}; pass --force")
    destination.parent.mkdir(parents=True, exist_ok=True)
    frame.to_parquet(destination, index=False)
    return destination


def print_json(payload: dict) -> None:
    print(json.dumps(payload, sort_keys=True, indent=2))

