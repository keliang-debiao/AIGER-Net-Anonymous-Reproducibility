from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd

from _common import ROOT, config_and_root, print_json
from aiger_net.baselines import (
    fit_predict_probabilities,
    sklearn_baseline,
    verify_external_baseline_lock,
    xgboost_baseline,
)
from aiger_net.calibration import TemperatureScaler
from aiger_net.data.folds import fold_view
from aiger_net.features import FeatureStore
from aiger_net.metrics import classification_metrics
from aiger_net.records import RunRecord


NATIVE = {
    "logistic_regression",
    "random_forest",
    "xgboost",
    "two_layer_mlp",
    "qwen3_vl_head",
}
VERIFIED_EXTERNAL = {"mcs_net", "artnas_style"}


def matrix(
    frame: pd.DataFrame,
    store: FeatureStore,
    with_geometry: bool,
    with_text: bool = False,
) -> np.ndarray:
    lookup = {str(work_id): index for index, work_id in enumerate(store.work_ids)}
    indices = np.asarray([lookup[str(item)] for item in frame["work_id"]], dtype=int)
    values = store.image_embeddings[indices]
    if with_text:
        text = store.text_embeddings[indices] * store.text_mask[indices, None]
        values = np.concatenate([values, text, store.text_mask[indices, None]], axis=1)
    if with_geometry:
        geometry = frame[["width", "height"]].to_numpy(dtype=np.float32)
        aspect = geometry[:, :1] / np.clip(geometry[:, 1:], 1.0, None)
        values = np.concatenate([values, geometry, aspect], axis=1)
    return values


def estimator(model_id: str, seed: int):
    if model_id == "xgboost":
        return xgboost_baseline(seed)
    if model_id == "qwen3_vl_head":
        return sklearn_baseline("two_layer_mlp", seed, {"hidden": 512})
    return sklearn_baseline(model_id, seed)


def run_native(
    model_id: str,
    config: dict,
    root: Path,
    artifact_root: Path,
    force: bool,
) -> list[dict]:
    seed = int(config["split"]["seed"])
    frame = pd.read_parquet(root / config["data"]["fold_manifest"])
    frame = frame.loc[frame["eligible_primary"].eq(1)].copy()
    store = FeatureStore.load(root / config["data"]["development_features"])
    with_geometry = model_id in {"random_forest", "xgboost"}
    with_text = model_id == "qwen3_vl_head"
    rows = []
    for fold in range(int(config["split"]["outer_folds"])):
        view = fold_view(
            frame,
            fold,
            float(config["split"]["calibration_artist_fraction"]),
            seed,
        )
        x_train = matrix(view.train, store, with_geometry, with_text)
        x_calibration = matrix(view.calibration, store, with_geometry, with_text)
        x_validation = matrix(view.validation, store, with_geometry, with_text)
        fitted = estimator(model_id, seed + fold)
        calibration_raw = fit_predict_probabilities(
            fitted,
            x_train,
            view.train["style_id"].to_numpy(dtype=int),
            x_calibration,
        )
        validation_raw = fitted.predict_proba(x_validation)
        scaler = TemperatureScaler().fit(
            calibration_raw,
            view.calibration["style_id"].to_numpy(dtype=int),
        )
        probabilities = scaler.transform(validation_raw)
        metrics = classification_metrics(
            probabilities,
            view.validation["style_id"].to_numpy(dtype=int),
            int(config["calibration"]["ece_bins"]),
        )
        output = artifact_root / f"predictions/baselines/{model_id}_fold_{fold}.npy"
        output.parent.mkdir(parents=True, exist_ok=True)
        if output.exists() and not force:
            raise FileExistsError(f"refusing to overwrite {output}; pass --force")
        np.save(output, probabilities)
        record = RunRecord(
            run_id=f"{model_id}_seed_{seed}_fold_{fold}",
            stage="baseline_evaluation",
            seed=seed,
            outer_fold=fold,
            command=" ".join(sys.argv),
            config=config,
            manifest_path=str(root / config["data"]["fold_manifest"]),
            metrics={"model_id": model_id, "temperature": scaler.temperature, **metrics},
            artifacts={"probabilities": str(output)},
        )
        destination = artifact_root / f"records/empirical/baselines/{model_id}_fold_{fold}.json"
        record.save(destination, force=force)
        rows.append(record.to_dict())
    return rows


def main() -> None:
    parser = argparse.ArgumentParser(description="Run matched baseline evaluations")
    parser.add_argument("--config", default=str(ROOT / "configs/base.yaml"))
    parser.add_argument("--model", required=True)
    parser.add_argument("--artifact-root", default=".")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    config, root = config_and_root(args.config)
    artifact_root = (root / args.artifact_root).resolve()
    if args.model in NATIVE:
        rows = run_native(args.model, config, root, artifact_root, args.force)
        print_json({"model": args.model, "folds": len(rows), "record_status": "empirical"})
        return
    if args.model in VERIFIED_EXTERNAL:
        entry = verify_external_baseline_lock(root / "third_party/LOCK.json", args.model)
        raise SystemExit(
            "the source lock is valid, but its repository-specific command must be run through "
            f"the adapter declared for revision {entry['revision']}"
        )
    raise SystemExit(
        "this model uses the image or feature-token training route; run the command recorded "
        "in configs/baselines.yaml and retain its empirical record"
    )


if __name__ == "__main__":
    main()
