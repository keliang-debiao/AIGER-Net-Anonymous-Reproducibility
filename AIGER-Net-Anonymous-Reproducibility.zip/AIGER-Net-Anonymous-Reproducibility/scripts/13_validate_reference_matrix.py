from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
REFERENCE = ROOT / "records/reference_only"


def close(actual: float, expected: float, digits: int = 3) -> None:
    if round(float(actual), digits) != round(float(expected), digits):
        raise AssertionError(f"{actual} does not match {expected} at {digits} decimals")


def main() -> None:
    frame = pd.read_csv(REFERENCE / "internal_folds.csv")
    folds = frame.loc[frame["outer_fold"].isin(["0", "1", "2", "3", "4"])].copy()
    if len(folds) != 5:
        numeric = pd.to_numeric(frame["outer_fold"], errors="coerce")
        folds = frame.loc[numeric.notna() & numeric.between(0, 4)].copy()
    mean_row = frame.loc[frame["outer_fold"].astype(str).eq("mean")].iloc[0]
    sd_row = frame.loc[frame["outer_fold"].astype(str).eq("sd")].iloc[0]
    metrics = ["macro_f1", "balanced_accuracy", "mcc", "top1_accuracy", "nll", "brier", "ece"]
    for metric in metrics:
        values = folds[metric].to_numpy(dtype=float)
        close(values.mean(), mean_row[metric])
        close(values.std(ddof=1), sd_row[metric])
    baselines = pd.read_csv(REFERENCE / "baseline_summary.csv")
    proposed = baselines.loc[baselines["model_id"].eq("aiger_net")].iloc[0]
    close(proposed["macro_f1_mean"], mean_row["macro_f1"])
    external = pd.read_csv(REFERENCE / "external_summary.csv")
    if int(external.loc[external["analysis_population"].eq("external_all_eligible"), "eligible_n"].min()) != 8299:
        raise AssertionError("external all-eligible population differs from the manuscript")
    print("reference matrix: pass")


if __name__ == "__main__":
    main()
