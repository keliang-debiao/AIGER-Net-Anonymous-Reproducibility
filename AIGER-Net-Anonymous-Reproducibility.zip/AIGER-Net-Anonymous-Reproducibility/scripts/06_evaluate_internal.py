from __future__ import annotations

import argparse
import json
import sys

import numpy as np
import pandas as pd
from sklearn.metrics import f1_score

from _common import ROOT, config_and_root, print_json
from aiger_net.calibration import select_rejection_rule
from aiger_net.evaluation import evaluate_internal, load_prediction_bundle
from aiger_net.io import sha256_file, write_json
from aiger_net.metrics import classification_metrics
from aiger_net.records import RunRecord
from aiger_net.statistics import artist_cluster_bootstrap


def main() -> None:
    value = argparse.ArgumentParser(description="Evaluate calibrated internal out-of-fold predictions")
    value.add_argument("--config", default=str(ROOT / "configs" / "base.yaml"))
    value.add_argument("--artifact-root", default=".")
    value.add_argument("--force", action="store_true")
    args = value.parse_args()
    config, root = config_and_root(args.config)
    artifact_root = (root / args.artifact_root).resolve()
    seed = int(config["split"]["seed"])
    fold_rows = []
    pooled_frames = []
    pooled_probabilities = []
    pooled_sets = []
    fold_decisions = {}
    for fold in range(int(config["split"]["outer_folds"])):
        calibration_frame, calibration_raw = load_prediction_bundle(
            artifact_root / f"predictions/fold_{fold}_calibration_raw"
        )
        validation_frame, validation_raw = load_prediction_bundle(
            artifact_root / f"predictions/fold_{fold}_validation_raw"
        )
        metrics, prediction_sets, temperature, aps = evaluate_internal(
            validation_raw,
            validation_frame["style_id"].to_numpy(dtype=int),
            calibration_raw,
            calibration_frame["style_id"].to_numpy(dtype=int),
            float(config["calibration"]["aps_target_coverage"]),
            int(config["calibration"]["ece_bins"]),
            seed + fold,
        )
        calibration_scaled = temperature.transform(calibration_raw)
        calibration_sets = aps.sets(calibration_scaled, seed=seed + 100 + fold)
        calibration_uncertainty = np.load(
            artifact_root / f"predictions/fold_{fold}_calibration_raw_uncertainty.npy"
        )
        rule = select_rejection_rule(
            calibration_scaled,
            calibration_frame["style_id"].to_numpy(dtype=int),
            calibration_uncertainty,
            calibration_sets,
            list(config["calibration"]["aps_size_grid"]),
            list(config["calibration"]["uncertainty_grid"]),
            list(config["calibration"]["confidence_grid"]),
            float(config["calibration"]["rejection_min_coverage"]),
            float(config["calibration"]["rejection_coverage_penalty"]),
        )
        calibrated = temperature.transform(validation_raw)
        fold_rows.append({"outer_fold": fold, "eligible_paintings": len(validation_frame), **metrics})
        pooled_frames.append(validation_frame)
        pooled_probabilities.append(calibrated)
        pooled_sets.append(prediction_sets)
        fold_decisions[str(fold)] = {
            "temperature": temperature.temperature,
            "aps_quantile": aps.quantile,
            "rejection": {
                "max_set_size": rule.max_set_size,
                "max_uncertainty": rule.max_uncertainty,
                "min_confidence": rule.min_confidence,
            },
        }
        np.save(artifact_root / f"predictions/fold_{fold}_validation_calibrated.npy", calibrated)
        np.save(artifact_root / f"predictions/fold_{fold}_validation_sets.npy", prediction_sets)
    fold_frame = pd.DataFrame(fold_rows)
    fold_output = artifact_root / "records/empirical/evaluation/internal_folds.csv"
    fold_output.parent.mkdir(parents=True, exist_ok=True)
    if fold_output.exists() and not args.force:
        raise FileExistsError(f"refusing to overwrite {fold_output}; pass --force")
    fold_frame.to_csv(fold_output, index=False)
    pooled_frame = pd.concat(pooled_frames, ignore_index=True)
    pooled = np.concatenate(pooled_probabilities)
    sets = np.concatenate(pooled_sets)
    labels = pooled_frame["style_id"].to_numpy(dtype=int)
    pooled_metrics = classification_metrics(pooled, labels, int(config["calibration"]["ece_bins"]))
    pooled_metrics["aps_coverage"] = float(sets[np.arange(len(labels)), labels].mean())
    pooled_metrics["aps_mean_size"] = float(sets.sum(axis=1).mean())
    point, lower, upper = artist_cluster_bootstrap(
        pooled_frame["artist_id"].to_numpy(),
        lambda index: f1_score(labels[index], pooled[index].argmax(axis=1), average="macro"),
        int(config["statistics"]["bootstrap_replicates"]),
        int(config["statistics"]["bootstrap_seed"]),
    )
    pooled_metrics["macro_f1_cluster_ci_lower"] = lower
    pooled_metrics["macro_f1_cluster_ci_upper"] = upper
    pooled_metrics["macro_f1_cluster_point"] = point
    pooled_metrics["ece_fold_mean"] = float(fold_frame["ece"].mean())
    pooled_metrics["ece_pooled"] = float(pooled_metrics["ece"])
    decision_path = artifact_root / "records/empirical/evaluation/fold_decisions.json"
    write_json(decision_path, fold_decisions, force=args.force)
    np.save(artifact_root / "predictions/internal_oof_calibrated.npy", pooled)
    pooled_frame.to_parquet(artifact_root / "predictions/internal_oof.parquet", index=False)
    np.save(artifact_root / "predictions/internal_oof_sets.npy", sets)
    record = RunRecord(
        run_id=f"seed_{seed}_internal_oof",
        stage="internal_evaluation",
        seed=seed,
        command=" ".join(sys.argv),
        config=config,
        manifest_path=str(root / config["data"]["fold_manifest"]),
        metrics=pooled_metrics,
        artifacts={"fold_metrics": str(fold_output), "fold_decisions": str(decision_path)},
    )
    record.predictions_sha256 = sha256_file(artifact_root / "predictions/internal_oof_calibrated.npy")
    record.save(artifact_root / "records/empirical/evaluation/internal_oof.json", force=args.force)
    print_json({"folds": fold_rows, "pooled": pooled_metrics})


if __name__ == "__main__":
    main()

