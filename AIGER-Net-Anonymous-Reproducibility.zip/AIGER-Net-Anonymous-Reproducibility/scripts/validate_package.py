from __future__ import annotations

import ast
import json
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]


def require_paths() -> list[str]:
    required = [
        "README.md",
        "ARTIFACT_STATUS.md",
        "configs/base.yaml",
        "metadata/manifest_schema.json",
        "metadata/run_record_schema.json",
        "records/reference_only/RECORD_STATUS.md",
        "scripts/run_full_pipeline.sh",
    ]
    return [item for item in required if not (ROOT / item).exists()]


def syntax_failures() -> list[str]:
    failures = []
    for path in sorted(ROOT.rglob("*.py")):
        try:
            ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        except SyntaxError as error:
            failures.append(f"{path.relative_to(ROOT)}:{error.lineno}:{error.msg}")
    return failures


def validate_reference_records() -> list[str]:
    failures = []
    required = {
        "schema_version",
        "record_status",
        "run_id",
        "stage",
        "seed",
        "config_sha256",
        "manifest_sha256",
        "source_revision",
        "command",
        "started_at",
        "ended_at",
        "metrics",
    }
    for path in sorted((ROOT / "records/reference_only").glob("*.json")):
        payload = json.loads(path.read_text(encoding="utf-8"))
        if payload.get("record_status") != "reference-only":
            failures.append(f"{path.name}: invalid record status")
        if payload.get("empirical") is not False:
            failures.append(f"{path.name}: empirical flag must be false")
        missing = sorted(required - set(payload))
        if missing:
            failures.append(f"{path.name}: missing fields {missing}")
        for field in ("config_sha256", "manifest_sha256"):
            value = str(payload.get(field, ""))
            if len(value) != 64 or any(character not in "0123456789abcdef" for character in value):
                failures.append(f"{path.name}: invalid {field}")
    for path in sorted((ROOT / "records/reference_only").glob("*.jsonl")):
        for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
            payload = json.loads(line)
            if payload.get("record_status") != "reference-only" or payload.get("empirical") is not False:
                failures.append(f"{path.name}:{line_number}: invalid reference-only disclosure")
    return failures


def validate_config() -> list[str]:
    config = yaml.safe_load((ROOT / "configs/base.yaml").read_text(encoding="utf-8"))
    paths = [
        "data.fold_manifest",
        "data.development_features",
        "split.outer_folds",
        "model.num_classes",
        "optimization.max_epochs",
        "calibration.aps_target_coverage",
        "statistics.bootstrap_replicates",
    ]
    failures = []
    for dotted in paths:
        node = config
        for part in dotted.split("."):
            if not isinstance(node, dict) or part not in node:
                failures.append(f"missing configuration field {dotted}")
                break
            node = node[part]
    if config.get("split", {}).get("outer_folds") != 5:
        failures.append("outer_folds must equal five")
    return failures


def main() -> None:
    failures = require_paths() + syntax_failures() + validate_config() + validate_reference_records()
    payload = {"status": "pass" if not failures else "fail", "failures": failures}
    print(json.dumps(payload, indent=2, sort_keys=True))
    if failures:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
