from __future__ import annotations

import pandas as pd

from _common import config_and_root, parser, print_json, write_parquet
from aiger_net.data.audit import summarize_manifest
from aiger_net.data.builders import build_wikiart_manifest


def main() -> None:
    args = parser("Build the WikiArt development manifest").parse_args()
    config, root = config_and_root(args.config)
    data = config["data"]
    external_path = root / data["external_manifest"]
    if not external_path.exists():
        raise FileNotFoundError("run 01_prepare_external.py before development preparation")
    external = pd.read_parquet(external_path)
    external_artists = set(external["artist_id"].astype(str))
    manifest = build_wikiart_manifest(
        root / data["wikiart_root"],
        root / data["label_map"],
        external_artists,
        int(data["text_min_alpha_tokens"]),
        int(data["phash_threshold"]),
        float(data["duplicate_embedding_cosine"]),
    )
    destination = root / data["development_manifest"]
    write_parquet(manifest, destination, args.force)
    print_json({"output": str(destination), **summarize_manifest(manifest).__dict__})


if __name__ == "__main__":
    main()

