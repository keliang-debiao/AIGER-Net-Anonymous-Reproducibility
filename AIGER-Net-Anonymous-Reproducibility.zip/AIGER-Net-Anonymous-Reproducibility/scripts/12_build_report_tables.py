from __future__ import annotations

import argparse
from pathlib import Path

from _common import ROOT, print_json
from aiger_net.reporting import load_records, metrics_frame


def main() -> None:
    parser = argparse.ArgumentParser(description="Build report tables from run records")
    parser.add_argument("--records", default=str(ROOT / "records/empirical"))
    parser.add_argument("--output", default=str(ROOT / "reports/generated"))
    parser.add_argument("--allow-reference-only", action="store_true")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    source = Path(args.records)
    paths = sorted(source.rglob("*.json"))
    if not paths:
        raise FileNotFoundError(f"no JSON records under {source}")
    records = load_records(paths, allow_reference_only=args.allow_reference_only)
    frame = metrics_frame(records)
    destination = Path(args.output) / "run_metrics.csv"
    if destination.exists() and not args.force:
        raise FileExistsError(f"refusing to overwrite {destination}; pass --force")
    destination.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(destination, index=False)
    print_json({"records": len(records), "output": str(destination)})


if __name__ == "__main__":
    main()
